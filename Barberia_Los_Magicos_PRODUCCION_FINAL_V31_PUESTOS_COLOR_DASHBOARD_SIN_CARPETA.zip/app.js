import { firebaseConfig, AUTH_ALIAS_DOMAIN } from "./firebase-config.js";

import {
  initializeApp,
  deleteApp
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";

import {
  getAuth,
  setPersistence,
  browserLocalPersistence,
  signInWithEmailAndPassword,
  signInAnonymously,
  signOut,
  onAuthStateChanged,
  createUserWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";

import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  query,
  where,
  onSnapshot,
  serverTimestamp,
  writeBatch,
  runTransaction
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";

const $ = id => document.getElementById(id);

const state = {
  chairs: [],
  barbers: [],
  services: [],
  products: [],
  sales: [],
  appointments: [],
  chargeRequests: [],
  clientAppointments: [],
  bookedSlots: []
};

let app;
let auth;
let db;
let currentRole = null;
let currentBarber = null;
let currentAdmin = null;
const ANY_BARBER = "__ANY__";
let booking = { serviceId: null, barberId: null };
let barberProductCart = [];
let bulkProductRows = [];
let productSearchQuery = "";
let barberServiceViewMode = "cards";
let dashboardFilterMode = "day";
let currentChairReceiptContext = null;
let currentPerformanceBarberId = null;
let currentChairOpsId = null;
let unsubscribers = [];

function money(v) {
  return new Intl.NumberFormat("es-PA", { style:"currency", currency:"USD" }).format(Number(v || 0));
}

function isoDay(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function jsDate(v) {
  if (!v) return new Date(0);
  if (typeof v.toDate === "function") return v.toDate();
  return new Date(v);
}

function todayIso(v) {
  return jsDate(v).toISOString().slice(0,10) === isoDay();
}

function fmtDateTime(v) {
  return jsDate(v).toLocaleString("es-PA", { day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit" });
}

function fmtDateOnly(day) {
  const [y,m,d] = String(day).split("-").map(Number);
  return new Date(y,m-1,d).toLocaleDateString("es-PA", { weekday:"short", day:"2-digit", month:"short" });
}

function escapeHtml(v) {
  return String(v ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  })[c]);
}

function statusLabel(v) {
  return {
    pending:"Pendiente", confirmed:"Confirmada", completed:"Completada", cancelled:"Cancelada",
    approved:"Aprobado", rejected:"Rechazado"
  }[v] || v;
}

function monthKey(value = new Date()) {
  const d = value instanceof Date ? value : jsDate(value);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;
}

function dayKey(value) {
  const d = jsDate(value);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function monthLabel(key) {
  if (!key) return "";
  const [year, month] = key.split("-").map(Number);
  return new Date(year, month-1, 1).toLocaleDateString("es-PA", { month:"long", year:"numeric" });
}

function shortDayLabel(key) {
  const [year, month, day] = key.split("-").map(Number);
  return new Date(year, month-1, day).toLocaleDateString("es-PA", { day:"2-digit", month:"short", year:"numeric" });
}


function parseIsoDayLocal(key) {
  const [y,m,d] = String(key || "").split("-").map(Number);
  return new Date(y || 1970, (m || 1)-1, d || 1);
}

function isoWeekValue(date = new Date()) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const day = d.getDay() || 7;
  d.setDate(d.getDate() + 4 - day);
  const yearStart = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return `${d.getFullYear()}-W${String(week).padStart(2,"0")}`;
}

function isoWeekBounds(value) {
  const match = String(value || "").match(/^(\d{4})-W(\d{2})$/);
  if (!match) {
    const today = isoDay();
    return { start:today, end:today };
  }
  const year = Number(match[1]);
  const week = Number(match[2]);
  const jan4 = new Date(year, 0, 4);
  const jan4Day = jan4.getDay() || 7;
  const monday = new Date(year, 0, 4 - jan4Day + 1 + (week - 1) * 7);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  return { start:isoDay(monday), end:isoDay(sunday) };
}

function dashboardPeriod() {
  const today = isoDay();
  const mode = dashboardFilterMode || "day";
  let start = today;
  let end = today;
  let label = "Hoy";

  if (mode === "day") {
    start = end = $("dashboardFilterDay")?.value || today;
    label = shortDayLabel(start);
  } else if (mode === "week") {
    const bounds = isoWeekBounds($("dashboardFilterWeek")?.value || isoWeekValue(new Date()));
    start = bounds.start;
    end = bounds.end;
    label = `${shortDayLabel(start)} – ${shortDayLabel(end)}`;
  } else if (mode === "range") {
    start = $("dashboardFilterStart")?.value || today;
    end = $("dashboardFilterEnd")?.value || start;
    if (start > end) [start, end] = [end, start];
    label = start === end ? shortDayLabel(start) : `${shortDayLabel(start)} – ${shortDayLabel(end)}`;
  } else if (mode === "month") {
    const key = $("dashboardFilterMonth")?.value || monthKey(new Date());
    const [year, month] = key.split("-").map(Number);
    start = `${year}-${String(month).padStart(2,"0")}-01`;
    end = isoDay(new Date(year, month, 0));
    label = monthLabel(key);
  }

  return { mode, start, end, label };
}

function dateKeyInPeriod(key, period = dashboardPeriod()) {
  return !!key && key >= period.start && key <= period.end;
}

function saleInDashboardPeriod(sale, period = dashboardPeriod()) {
  return dateKeyInPeriod(dayKey(sale.date), period);
}

function appointmentInDashboardPeriod(appt, period = dashboardPeriod()) {
  return dateKeyInPeriod(appt.date, period);
}

function openNativeDatePicker(input) {
  if (!input) return;
  try {
    input.focus({ preventScroll:true });
    if (typeof input.showPicker === "function") input.showPicker();
  } catch (_) {
    input.focus();
  }
}

function setDashboardFilterMode(mode, render = true) {
  dashboardFilterMode = ["day","week","range","month"].includes(mode) ? mode : "day";
  document.querySelectorAll("[data-dashboard-filter-mode]").forEach(btn =>
    btn.classList.toggle("active", btn.dataset.dashboardFilterMode === dashboardFilterMode)
  );
  document.querySelectorAll("[data-dashboard-filter-control]").forEach(node =>
    node.classList.toggle("active", node.dataset.dashboardFilterControl === dashboardFilterMode)
  );

  // Al seleccionar Rango, abrir inmediatamente el calendario "Desde".
  // Si el navegador no soporta showPicker(), el campo queda enfocado y usa el selector nativo.
  if (dashboardFilterMode === "range") openNativeDatePicker($("dashboardFilterStart"));

  if (render && currentRole === "admin") renderDashboard();
}

function resetDashboardFilterToToday() {
  const today = isoDay();
  if ($("dashboardFilterDay")) $("dashboardFilterDay").value = today;
  if ($("dashboardFilterWeek")) $("dashboardFilterWeek").value = isoWeekValue(new Date());
  if ($("dashboardFilterStart")) $("dashboardFilterStart").value = today;
  if ($("dashboardFilterEnd")) $("dashboardFilterEnd").value = today;
  if ($("dashboardFilterMonth")) $("dashboardFilterMonth").value = monthKey(new Date());
  setDashboardFilterMode("day");
}

function initializeDashboardFilter() {
  const today = isoDay();
  if ($("dashboardFilterDay")) $("dashboardFilterDay").value = today;
  if ($("dashboardFilterWeek")) $("dashboardFilterWeek").value = isoWeekValue(new Date());
  if ($("dashboardFilterStart")) $("dashboardFilterStart").value = today;
  if ($("dashboardFilterEnd")) $("dashboardFilterEnd").value = today;
  if ($("dashboardFilterMonth")) $("dashboardFilterMonth").value = monthKey(new Date());
  setDashboardFilterMode("day", false);
}

function toast(message) {
  const node = $("toast");
  node.textContent = message;
  node.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => node.classList.remove("show"), 2600);
}

function show(id) { const el = $(id); if (el) el.classList.remove("hidden"); }
function hide(id) { const el = $(id); if (el) el.classList.add("hidden"); }
function openModal(id) { const el = $(id); if (el) el.classList.add("show"); }
function closeModal(id) { const el = $(id); if (el) el.classList.remove("show"); }

function bind(id, eventName, handler) {
  const el = $(id);
  if (!el) {
    console.warn(`[Los Mágicos] Elemento opcional no encontrado: #${id}`);
    return;
  }
  el.addEventListener(eventName, handler);
}

function cleanupListeners() {
  for (const unsub of unsubscribers) {
    try { unsub(); } catch {}
  }
  unsubscribers = [];
}

function usernameToEmail(username) {
  const clean = String(username || "").trim().toLowerCase().replace(/[^a-z0-9._-]/g, "");
  return `${clean}@${AUTH_ALIAS_DOMAIN}`;
}

function firebaseErrorMessage(err, fallback = "Ocurrió un error") {
  const code = String(err?.code || "");
  if (code.includes("auth/unauthorized-domain")) {
    return "Este dominio no está autorizado en Firebase. Agrega tu dominio de GitHub Pages en Authentication → Configuración → Dominios autorizados.";
  }
  if (code.includes("auth/invalid-credential") || code.includes("auth/wrong-password") || code.includes("auth/user-not-found")) {
    return "Credenciales incorrectas.";
  }
  if (code.includes("auth/email-already-in-use")) return "Ese usuario ya existe.";
  if (code.includes("auth/weak-password")) return "La contraseña debe tener al menos 6 caracteres.";
  if (code.includes("permission-denied")) return "Firebase rechazó la operación por permisos. Revisa las reglas de Firestore.";
  if (code.includes("failed-precondition")) return "Falta una configuración o índice de Firebase.";
  return fallback;
}

async function initFirebase() {
  try {
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    await setPersistence(auth, browserLocalPersistence);
    db = getFirestore(app);
    return true;
  } catch (err) {
    console.error(err);
    const alert = $("firebaseAlert");
    alert.textContent = "No se pudo iniciar Firebase. Revisa firebase-config.js.";
    alert.classList.remove("hidden");
    return false;
  }
}

function resetScreens() {
  hide("adminApp");
  hide("barberApp");
  hide("clientApp");
  show("accessScreen");
}

async function logout() {
  cleanupListeners();
  currentRole = null;
  currentBarber = null;
  currentAdmin = null;
  booking = { serviceId:null, barberId:null };
  try {
    if (auth?.currentUser) await signOut(auth);
  } catch {}
  resetScreens();
}

function wireStaticUI() {
  bind("openAdmin", "click", () => openModal("adminLoginModal"));
  bind("openBarber", "click", () => openModal("barberLoginModal"));
  bind("openClient", "click", enterClient);

  document.querySelectorAll("[data-close]").forEach(btn =>
    btn.addEventListener("click", () => closeModal(btn.dataset.close))
  );

  document.querySelectorAll(".modal-backdrop").forEach(modal =>
    modal.addEventListener("click", e => {
      if (e.target === modal) closeModal(modal.id);
    })
  );

  document.querySelectorAll("[data-logout]").forEach(btn =>
    btn.addEventListener("click", logout)
  );

  document.querySelectorAll(".nav-item").forEach(btn =>
    btn.addEventListener("click", () => switchAdminView(btn.dataset.view))
  );

  document.querySelectorAll("[data-go]").forEach(btn =>
    btn.addEventListener("click", () => switchAdminView(btn.dataset.go))
  );

  bind("adminMenuBtn", "click", () => $("adminSidebar").classList.toggle("open"));
  bind("appointmentFilter", "change", renderAppointments);
  bind("saleService", "change", syncSalePrice);
  bind("saleBarber", "change", syncSaleChair);
  bind("clientDate", "change", () => {
    updateSelectedDateSummary();
    renderAvailableTimes();
  });
  bind("clientDate", "input", () => {
    updateSelectedDateSummary();
    renderAvailableTimes();
  });
  bind("clientDatePickerBtn", "click", openClientDatePicker);
  document.querySelectorAll("[data-date-offset]").forEach(btn =>
    btn.addEventListener("click", () => setClientDateOffset(Number(btn.dataset.dateOffset || 0)))
  );

  document.querySelectorAll("[data-password-target]").forEach(btn =>
    btn.addEventListener("click", () => {
      const input = $(btn.dataset.passwordTarget);
      if (!input) return;
      const showing = input.type === "text";
      input.type = showing ? "password" : "text";
      btn.classList.toggle("showing", !showing);
      btn.setAttribute("aria-label", showing ? "Mostrar contraseña" : "Ocultar contraseña");
    })
  );

  document.querySelectorAll("[data-service-view]").forEach(btn =>
    btn.addEventListener("click", () => setBarberServiceView(btn.dataset.serviceView))
  );

  bind("openTodayAppointmentsBtn", "click", openDashboardAppointmentsModal);
  bind("appointmentsTodayBtn", "click", openTodayAppointmentsModal);
  bind("todayAppointmentsCard", "click", openDashboardAppointmentsModal);
  bind("todayAppointmentsCard", "keydown", e => {
    if (e.key === "Enter" || e.key === " ") openDashboardAppointmentsModal();
  });
  bind("openBarberTodayAppointmentsBtn", "click", openBarberTodayAppointmentsModal);
  bind("toggleBarberAvailabilityBtn", "click", toggleCurrentBarberChairOccupied);

  document.querySelectorAll("[data-dashboard-filter-mode]").forEach(btn =>
    btn.addEventListener("click", () => setDashboardFilterMode(btn.dataset.dashboardFilterMode))
  );
  ["dashboardFilterDay","dashboardFilterWeek","dashboardFilterStart","dashboardFilterEnd","dashboardFilterMonth"].forEach(id => {
    bind(id, "change", () => currentRole === "admin" && renderDashboard());
    bind(id, "click", e => {
      const input = e.currentTarget;
      if (typeof input?.showPicker === "function") {
        try { input.showPicker(); } catch (_) {}
      }
    });
  });
  bind("dashboardFilterTodayBtn", "click", resetDashboardFilterToToday);
  initializeDashboardFilter();

  $("reportMonth").value = monthKey(new Date());
  bind("reportMonth", "change", renderReports);
  bind("printReportBtn", "click", () => {
    const period = dashboardPeriod();
    if ($("reportMonth")) $("reportMonth").value = period.start.slice(0,7);
    renderReports();
    window.print();
  });

  ["quickSaleBtn","newSaleBtn"].forEach(id =>
    bind(id, "click", () => openModal("saleModal"))
  );

  bind("addBarberBtn", "click", () => openModal("barberModal"));
  bind("addServiceBtn", "click", () => openModal("serviceModal"));
  bind("addProductBtn", "click", openNewProductModal);
  bind("productSearchInput", "input", e => {
    productSearchQuery = String(e.currentTarget.value || "");
    renderProducts();
  });
  bind("productSearchInput", "keydown", e => {
    if (e.key !== "Enter") return;
    e.preventDefault();
    const code = normalizeBarcode(e.currentTarget.value);
    if (!code) return;
    const product = findProductByBarcode(code);
    if (!product) return toast("Ese código de barras no está registrado.");
    productSearchQuery = code;
    e.currentTarget.value = code;
    renderProducts();
    requestAnimationFrame(() => {
      const row = document.querySelector(`[data-product-row="${product.id}"]`);
      row?.scrollIntoView({ behavior:"smooth", block:"center" });
      row?.classList.add("scan-highlight");
      setTimeout(() => row?.classList.remove("scan-highlight"), 1400);
    });
  });
  bind("bulkProductsBtn", "click", openBulkProductsModal);
  bind("bulkAddRowBtn", "click", () => addBulkProductRow());
  bind("bulkClearBtn", "click", resetBulkProductRows);
  bind("bulkPasteToggleBtn", "click", () => $("bulkPastePanel")?.classList.remove("hidden"));
  bind("bulkPasteCancelBtn", "click", () => $("bulkPastePanel")?.classList.add("hidden"));
  bind("bulkPasteImportBtn", "click", importBulkPasteText);
  bind("bulkProductsSaveBtn", "click", saveBulkProducts);
  bind("productSalesTodayBtn", "click", openProductSalesTodayModal);
  bind("printInventoryBtn", "click", printInventoryReport);
  bind("exportApprovedSalesBtn", "click", exportApprovedSalesExcel);
  bind("printChairPaymentReceiptBtn", "click", printChairPaymentReceipt);
  bind("printBarberPerformanceBtn", "click", printBarberPerformanceReport);

  bind("adminLoginForm", "submit", adminLogin);
  bind("barberLoginForm", "submit", barberLogin);
  bind("barberChargeForm", "submit", submitBarberChargeRequest);
  bind("barberChargeService", "change", syncBarberChargePrice);
  bind("barberChargeChair", "change", renderBarberChargePreview);
  bind("barberChargePrice", "input", renderBarberChargePreview);
  bind("barberChargePayment", "change", renderBarberChargePreview);
  bind("barberAddProductBtn", "click", addProductToBarberCharge);
  bind("saleForm", "submit", saveSale);
  bind("barberForm", "submit", createBarber);
  bind("commissionForm", "submit", saveBarberCommissions);
  bind("barberChairForm", "submit", saveBarberFixedChair);
  bind("serviceForm", "submit", createService);
  bind("productForm", "submit", createProduct);
  bind("productStockForm", "submit", saveProductStock);
  bind("clientBookingForm", "submit", createAppointment);
  bind("addChairBtn", "click", createChair);
  bind("chairAssignForm", "submit", saveChairAssignment);
  bind("chairOpsAssignBtn", "click", () => currentChairOpsId && openChairAssignmentModal(currentChairOpsId));
  bind("chairOpsBusyBtn", "click", () => currentChairOpsId && toggleChairOccupied(currentChairOpsId));
  bind("chairOpsActiveBtn", "click", () => currentChairOpsId && toggleChairActive(currentChairOpsId));
  bind("barberProfitFilterBtn", "click", () => {
    const period = dashboardPeriod();
    const modalMonth = $("barberProfitMonth");
    if (modalMonth) modalMonth.value = period.start.slice(0,7);
    if ($("reportMonth")) $("reportMonth").value = period.start.slice(0,7);
    renderBarberProfitFilter();
    openModal("barberProfitModal");
  });
  bind("barberProfitSelect", "change", renderBarberProfitFilter);
  bind("barberProfitMonth", "change", renderBarberProfitFilter);
  bind("exportExcelBtn", "click", () => {
    const period = dashboardPeriod();
    if ($("reportMonth")) $("reportMonth").value = period.start.slice(0,7);
    exportExcelReport();
  });
}

async function adminLogin(e) {
  e.preventDefault();
  try {
    const email = $("adminEmail").value.trim().toLowerCase();
    const password = $("adminPassword").value;

    const result = await signInWithEmailAndPassword(auth, email, password);
    const profileSnap = await getDoc(doc(db, "users", result.user.uid));

    if (!profileSnap.exists()) {
      await signOut(auth);
      return toast("La cuenta existe en Authentication, pero falta su documento en Firestore /users.");
    }

    const profile = { id:profileSnap.id, ...profileSnap.data() };
    if (profile.role !== "admin" || profile.active === false) {
      await signOut(auth);
      return toast("Esta cuenta no tiene rol de administrador.");
    }

    currentRole = "admin";
    currentAdmin = profile;
    closeModal("adminLoginModal");
    hide("accessScreen");
    show("adminApp");
    $("adminDisplayName").textContent = profile.name || "Administrador";
    await ensureSeedData();
    subscribeAdmin();
    toast("Bienvenido a Los Mágicos");
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo iniciar sesión."));
  }
}

async function barberLogin(e) {
  e.preventDefault();
  const username = $("barberUsernameLogin").value.trim().toLowerCase();
  const password = $("barberPasswordLogin").value;

  try {
    const result = await signInWithEmailAndPassword(auth, usernameToEmail(username), password);
    const profileSnap = await getDoc(doc(db, "users", result.user.uid));

    if (!profileSnap.exists()) {
      await signOut(auth);
      return toast("El usuario no tiene perfil en Firestore.");
    }

    const profile = { id:profileSnap.id, ...profileSnap.data() };
    if (profile.role !== "barber" || profile.active === false) {
      await signOut(auth);
      return toast("Esta cuenta de barbero no está activa.");
    }

    currentRole = "barber";
    currentBarber = profile;
    closeModal("barberLoginModal");
    hide("accessScreen");
    show("barberApp");
    subscribeBarber(profile.id);
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo iniciar sesión."));
  }
}

async function enterClient() {
  try {
    cleanupListeners();

    if (auth.currentUser && !auth.currentUser.isAnonymous) await signOut(auth);
    if (!auth.currentUser) await signInAnonymously(auth);

    currentRole = "client";
    hide("accessScreen");
    show("clientApp");
    subscribeClient(auth.currentUser.uid);
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo abrir el módulo Cliente."));
  }
}

async function ensureSeedData() {
  const [chairsSnap, servicesSnap] = await Promise.all([
    getDocs(collection(db, "chairs")),
    getDocs(collection(db, "services"))
  ]);

  const batch = writeBatch(db);
  let changes = false;

  if (chairsSnap.empty) {
    for (let i=1; i<=4; i++) {
      batch.set(doc(db, "chairs", `puesto-${i}`), {
        name:`Puesto ${i}`, active:true, order:i, createdAt:serverTimestamp()
      });
    }
    changes = true;
  }

  if (servicesSnap.empty) {
    [
      ["corte-clasico","Corte clásico",12,30],
      ["corte-barba","Corte + barba",18,45],
      ["barba-premium","Barba premium",10,30],
      ["corte-infantil","Corte infantil",10,30]
    ].forEach(([id,name,price,duration], i) => {
      batch.set(doc(db, "services", id), {
        name, price, duration, active:true, order:i+1, createdAt:serverTimestamp()
      });
    });
    changes = true;
  }

  if (changes) await batch.commit();
}

function subscribeAdmin() {
  cleanupListeners();

  unsubscribers.push(onSnapshot(collection(db, "chairs"), snap => {
    state.chairs = snap.docs.map(d => ({ id:d.id, ...d.data() })).sort((a,b)=>(a.order||999)-(b.order||999));
    renderAdminAll();
  }));

  unsubscribers.push(onSnapshot(query(collection(db, "users"), where("role","==","barber")), snap => {
    state.barbers = snap.docs.map(d => ({ id:d.id, ...d.data() })).sort((a,b)=>(a.name||"").localeCompare(b.name||""));
    renderAdminAll();
  }));

  unsubscribers.push(onSnapshot(collection(db, "services"), snap => {
    state.services = snap.docs.map(d => ({ id:d.id, ...d.data() })).sort((a,b)=>(a.order||999)-(b.order||999));
    renderAdminAll();
  }));

  unsubscribers.push(onSnapshot(collection(db, "products"), snap => {
    state.products = snap.docs.map(d => ({ id:d.id, ...d.data() })).sort((a,b)=>(a.order||999)-(b.order||999));
    renderAdminAll();
  }));

  unsubscribers.push(onSnapshot(collection(db, "sales"), snap => {
    state.sales = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderAdminAll();
  }));

  unsubscribers.push(onSnapshot(collection(db, "chargeRequests"), snap => {
    state.chargeRequests = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderAdminAll();
  }));

  unsubscribers.push(onSnapshot(collection(db, "appointments"), snap => {
    state.appointments = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderAdminAll();
  }));
}

function subscribeBarber(uid) {
  cleanupListeners();

  unsubscribers.push(onSnapshot(collection(db, "chairs"), snap => {
    state.chairs = snap.docs.map(d => ({ id:d.id, ...d.data() })).filter(x => x.active !== false).sort((a,b)=>(a.order||999)-(b.order||999));
    renderBarberPortal();
  }));

  unsubscribers.push(onSnapshot(collection(db, "services"), snap => {
    state.services = snap.docs.map(d => ({ id:d.id, ...d.data() })).filter(x => x.active !== false).sort((a,b)=>(a.order||999)-(b.order||999));
    renderBarberPortal();
  }));

  unsubscribers.push(onSnapshot(collection(db, "products"), snap => {
    state.products = snap.docs.map(d => ({ id:d.id, ...d.data() })).filter(x => x.active !== false).sort((a,b)=>(a.order||999)-(b.order||999));
    renderBarberPortal();
  }));

  unsubscribers.push(onSnapshot(query(collection(db, "chargeRequests"), where("barberId","==",uid)), snap => {
    state.chargeRequests = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderBarberPortal();
  }));

  unsubscribers.push(onSnapshot(doc(db, "users", uid), snap => {
    if (!snap.exists()) return;
    currentBarber = { id:snap.id, ...snap.data() };
    if (currentBarber.active === false) return logout();
    renderBarberPortal();
  }));

  unsubscribers.push(onSnapshot(query(collection(db, "sales"), where("barberId","==",uid)), snap => {
    state.sales = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderBarberPortal();
  }));

  unsubscribers.push(onSnapshot(query(collection(db, "appointments"), where("barberId","==",uid)), snap => {
    state.appointments = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderBarberPortal();
  }));
}

function subscribeClient(uid) {
  cleanupListeners();

  unsubscribers.push(onSnapshot(collection(db, "publicBarbers"), snap => {
    state.barbers = snap.docs.map(d => ({ id:d.id, ...d.data() })).filter(x => x.active !== false).sort((a,b)=>(a.name||"").localeCompare(b.name||""));
    renderClientOptions();
  }));

  unsubscribers.push(onSnapshot(collection(db, "services"), snap => {
    state.services = snap.docs.map(d => ({ id:d.id, ...d.data() })).filter(x => x.active !== false).sort((a,b)=>(a.order||999)-(b.order||999));
    renderClientOptions();
  }));

  unsubscribers.push(onSnapshot(query(collection(db, "appointments"), where("ownerUid","==",uid)), snap => {
    state.clientAppointments = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderClientAppointments();
  }));

  unsubscribers.push(onSnapshot(query(collection(db, "bookedSlots"), where("date",">=",isoDay())), snap => {
    state.bookedSlots = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderAvailableTimes();
  }));

  $("clientDate").min = isoDay();
  const maxBookingDate = new Date();
  maxBookingDate.setFullYear(maxBookingDate.getFullYear() + 1);
  $("clientDate").max = isoDay(maxBookingDate);
  if (!$("clientDate").value) $("clientDate").value = isoDay();
  updateSelectedDateSummary();
  renderClientOptions();
  renderClientAppointments();
}

function switchAdminView(name) {
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(v => v.classList.remove("active"));
  $(`view-${name}`).classList.add("active");
  const btn = document.querySelector(`[data-view="${name}"]`);
  if (btn) btn.classList.add("active");

  const titles = {
    dashboard:"Dashboard", sales:"Cobros", appointments:"Citas",
    barbers:"Usuarios / Barberos", chairs:"Puestos", services:"Servicios", products:"Productos", reports:"Reportes"
  };
  $("adminPageTitle").textContent = titles[name] || "Dashboard";
  const dashboardTopMessage = $("dashboardTopMessage");
  if (dashboardTopMessage) dashboardTopMessage.classList.toggle("hidden", name !== "dashboard");
  const dashboardTopbar = document.querySelector(".dashboard-topbar");
  if (dashboardTopbar) dashboardTopbar.classList.toggle("dashboard-mode", name === "dashboard");
  $("adminSidebar").classList.remove("open");
}

function renderAdminAll() {
  if (currentRole !== "admin") return;
  renderSelectors();
  renderDashboard();
  renderSales();
  renderPendingChargeRequests();
  renderAppointments();
  renderBarbers();
  renderChairs();
  renderServices();
  renderProducts();
  renderReports();
  hydrateBarberChairSelectors();
}

function renderSelectors() {
  const barbers = state.barbers.filter(x => x.active !== false);
  const services = state.services.filter(x => x.active !== false);

  $("saleBarber").innerHTML = barbers.length
    ? barbers.map(x => `<option value="${x.id}">${escapeHtml(x.name)} · ${escapeHtml(x.chairName || "Sin puesto fijo")} · ${Number(x.commission ?? 50)}%</option>`).join("")
    : `<option value="">Sin barberos activos</option>`;

  $("saleService").innerHTML = services.length
    ? services.map(x => `<option value="${x.id}">${escapeHtml(x.name)} · ${money(x.price)}</option>`).join("")
    : `<option value="">Sin servicios</option>`;

  syncSaleChair();
  syncSalePrice();
}

function syncSaleChair() {
  const barber = state.barbers.find(x => x.id === $("saleBarber").value && x.active !== false);
  const chairSelect = $("saleChair");
  if (!chairSelect) return;

  if (!barber || !barber.chairId) {
    chairSelect.innerHTML = `<option value="">Barbero sin puesto fijo</option>`;
    chairSelect.value = "";
    return;
  }

  const chair = state.chairs.find(c => c.id === barber.chairId && c.active !== false);
  if (!chair) {
    chairSelect.innerHTML = `<option value="">Puesto no disponible</option>`;
    chairSelect.value = "";
    return;
  }

  chairSelect.innerHTML = `<option value="${chair.id}">${escapeHtml(chair.name)}</option>`;
  chairSelect.value = chair.id;
}

function syncSalePrice() {
  const service = state.services.find(x => x.id === $("saleService").value);
  if (service) $("salePrice").value = Number(service.price).toFixed(2);
}

function renderDashboard() {
  const period = dashboardPeriod();
  const ds = state.sales.filter(s => saleInDashboardPeriod(s, period));
  const da = state.appointments.filter(a =>
    appointmentInDashboardPeriod(a, period) && !["completed","cancelled"].includes(a.status)
  );

  const singleToday = period.start === isoDay() && period.end === isoDay();
  const periodWord = singleToday ? "hoy" : "período";
  const periodTitle = singleToday ? "HOY" : period.label.toUpperCase();

  if ($("dashboardPeriodLabel")) $("dashboardPeriodLabel").textContent = period.label;
  if ($("statSalesLabel")) $("statSalesLabel").textContent = singleToday ? "Ventas de hoy" : "Ventas del período";
  if ($("statBarbersLabel")) $("statBarbersLabel").textContent = "Pago a barberos";
  if ($("statShopLabel")) $("statShopLabel").textContent = "Ingreso barbería";
  if ($("statAppointmentsLabel")) $("statAppointmentsLabel").textContent = singleToday ? "Citas de hoy" : "Citas del período";
  if ($("statBarbersMeta")) $("statBarbersMeta").textContent = `Comisiones del ${periodWord}`;
  if ($("statShopMeta")) $("statShopMeta").textContent = `Participación del ${periodWord}`;

  $("statSales").textContent = money(ds.reduce((a,s)=>a+Number(s.total||0),0));
  $("statBarbers").textContent = money(ds.reduce((a,s)=>a+Number(s.barberAmount||0),0));
  $("statShop").textContent = money(ds.reduce((a,s)=>a+Number(s.shopAmount||0),0));
  $("statSalesCount").textContent = `${ds.length} servicio${ds.length===1?"":"s"}`;
  $("statAppointments").textContent = da.length;
  $("statAppointmentsMeta").textContent = `${da.filter(a=>a.status==="pending").length} pendientes · Ver detalle`;

  renderDashboardChairStatus();

  if ($("dashboardChairKicker")) $("dashboardChairKicker").textContent = `PUESTOS · ${periodTitle}`;
  if ($("dashboardChairHeading")) $("dashboardChairHeading").textContent = singleToday ? "Producción diaria por puesto" : "Producción por puesto";
  if ($("dashboardChairCaption")) $("dashboardChairCaption").textContent = `Barbero asignado, total generado y distribución · ${period.label}.`;
  if ($("dashboardAgendaKicker")) $("dashboardAgendaKicker").textContent = singleToday ? "AGENDA DE HOY" : "AGENDA DEL PERÍODO";
  if ($("dashboardAgendaHeading")) $("dashboardAgendaHeading").textContent = singleToday ? "Citas del día" : "Citas del período";
  if ($("openTodayAppointmentsBtn")) $("openTodayAppointmentsBtn").textContent = singleToday ? "Ver citas de hoy" : "Ver citas del período";

  const recent = [...ds]
    .sort((a,b)=>jsDate(b.date)-jsDate(a.date))
    .slice(0,5);

  const recentSalesNode = $("recentSales");
  if (recentSalesNode) recentSalesNode.innerHTML = recent.length ? recent.map(s =>     `
    <div class="list-row">
      <div>
        <div class="item-title">${escapeHtml(s.serviceName)}</div>
        <div class="item-meta">${escapeHtml(s.barberName)} · ${fmtDateTime(s.date)}</div>
      </div>
      <div class="amount">${money(s.total)}</div>
    </div>
  `).join("") : `<div class="empty">No hay cobros en ${escapeHtml(period.label)}.</div>`;

  const periodRows = [...da]
    .sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time))
    .slice(0,4);

  const upcomingAppointmentsNode = $("upcomingAppointments");
  if (upcomingAppointmentsNode) upcomingAppointmentsNode.innerHTML = periodRows.length ? periodRows.map(a =>     `
    <button class="list-row dashboard-appt-row" type="button" data-open-dashboard-appts>
      <div>
        <div class="item-title">${fmtDateOnly(a.date)} · ${a.time} · ${escapeHtml(a.clientName)}</div>
        <div class="item-meta">${escapeHtml(a.serviceName)} · ${escapeHtml(a.barberName || "Por asignar")}</div>
      </div>
      <span class="status ${a.status}">${statusLabel(a.status)}</span>
    </button>
  `).join("") : `<div class="empty">No hay citas en ${escapeHtml(period.label)}.</div>`;

  document.querySelectorAll("[data-open-dashboard-appts]").forEach(btn =>
    btn.addEventListener("click", openDashboardAppointmentsModal)
  );

  renderBarberPerformanceChart(ds, period);
}

function renderDashboardChairStatus() {
  const node = $("dashboardChairStatus");
  if (!node) return;

  if (!state.chairs.length) {
    node.innerHTML = `<div class="dashboard-chair-status-empty">No hay puestos configurados.</div>`;
    return;
  }

  node.innerHTML = state.chairs.map((chair,index) => {
    const status = chairOperationalStatus(chair);
    const assigned = chairAssignedBarbers(chair.id, true)[0] || null;
    const statusLabelText = status.key === "occupied" ? "Ocupado" : status.key === "available" ? "Disponible" : "Fuera de servicio";
    const chairIndex = String(index + 1).padStart(2, "0");
    return `
      <button class="dashboard-chair-status-badge ${status.key}" type="button" data-dashboard-chair-open="${chair.id}" title="Abrir ${escapeHtml(chair.name)}">
        <span class="dashboard-chair-badge-name">${escapeHtml((chair.name || `Puesto ${index+1}`).toUpperCase())}</span>
        <span class="dashboard-chair-badge-meta">${chairIndex} · ${statusLabelText}</span>
        <small>${assigned ? escapeHtml(assigned.name) : "Sin barbero asignado"}</small>
      </button>`;
  }).join("");

  document.querySelectorAll("[data-dashboard-chair-open]").forEach(btn =>
    btn.addEventListener("click", () => {
      switchAdminView("chairs");
      setTimeout(() => openChairOperations(btn.dataset.dashboardChairOpen), 60);
    })
  );
}

function renderBarberPerformanceChart(periodSales = [], period = dashboardPeriod()) {
  const node = $("barberPerformanceChart");
  if (!node) return;

  const singleToday = period.start === isoDay() && period.end === isoDay();
  if ($("barberPerformanceKicker")) $("barberPerformanceKicker").textContent = singleToday ? "RENDIMIENTO · HOY" : `RENDIMIENTO · ${period.label.toUpperCase()}`;
  if ($("barberPerformanceCaption")) $("barberPerformanceCaption").textContent = `Comparación de producción y ganancia del barbero · ${period.label}.`;

  const rows = state.barbers
    .filter(b => b.active !== false)
    .map(barber => {
      const sales = periodSales.filter(s => s.barberId === barber.id);
      return {
        barber,
        count:sales.length,
        gross:sales.reduce((sum,s)=>sum+Number(s.total||0),0),
        pay:sales.reduce((sum,s)=>sum+Number(s.barberAmount||0),0)
      };
    })
    .sort((a,b)=>b.gross-a.gross || a.barber.name.localeCompare(b.barber.name));

  if (!rows.length) {
    node.innerHTML = `<div class="barber-performance-empty">No hay barberos activos para mostrar.</div>`;
    return;
  }

  const maxValue = Math.max(...rows.flatMap(r => [r.gross, r.pay]), 1);
  const niceMax = Math.ceil(maxValue / 20) * 20 || 20;

  node.innerHTML = `
    <div class="performance-horizontal-scale" aria-hidden="true">
      <span>0</span><span>25%</span><span>50%</span><span>75%</span><span>${money(niceMax)}</span>
    </div>
    <div class="performance-horizontal-rows">
      ${rows.map((r,index) => {
        const grossPct = Math.min(100, Math.max(r.gross > 0 ? 2 : 0, (r.gross / niceMax) * 100));
        const payPct = Math.min(100, Math.max(r.pay > 0 ? 2 : 0, (r.pay / niceMax) * 100));
        const initials = (r.barber.name || "B").split(/\s+/).slice(0,2).map(x=>x.charAt(0)).join("").toUpperCase();
        return `
          <article class="performance-horizontal-row ${index===0 && r.gross>0 ? "top-performer" : ""}">
            <button class="performance-horizontal-barber" type="button" data-performance-barber="${r.barber.id}" title="Ver detalle de ${escapeHtml(r.barber.name)}">
              <span class="performance-name-avatar">${escapeHtml(initials)}</span>
              <span class="performance-horizontal-name">
                <strong>${escapeHtml(r.barber.name)}</strong>
                <small>${r.count} servicio${r.count===1?"":"s"} · Ver detalle</small>
              </span>
            </button>
            <div class="performance-horizontal-metrics">
              <div class="performance-horizontal-metric production-metric">
                <div class="performance-horizontal-label"><span>Producción</span><strong>${money(r.gross)}</strong></div>
                <div class="performance-horizontal-track"><i class="production-fill" style="width:${grossPct}%"></i></div>
              </div>
              <div class="performance-horizontal-metric gain-metric">
                <div class="performance-horizontal-label"><span>Ganancia barbero</span><strong>${money(r.pay)}</strong></div>
                <div class="performance-horizontal-track"><i class="gain-fill" style="width:${payPct}%"></i></div>
              </div>
            </div>
          </article>`;
      }).join("")}
    </div>`;

  document.querySelectorAll("[data-performance-barber]").forEach(btn =>
    btn.addEventListener("click", () => openBarberPerformanceDetail(btn.dataset.performanceBarber))
  );
}

function openBarberPerformanceDetail(barberId) {
  const barber = state.barbers.find(b => b.id === barberId);
  if (!barber) return toast("No se encontró el barbero.");

  currentPerformanceBarberId = barberId;
  const period = dashboardPeriod();
  const rows = state.sales
    .filter(s => s.barberId === barberId && saleInDashboardPeriod(s, period))
    .sort((a,b)=>jsDate(b.date)-jsDate(a.date));

  const gross = rows.reduce((sum,s)=>sum+Number(s.total||0),0);
  const pay = rows.reduce((sum,s)=>sum+Number(s.barberAmount||0),0);
  const average = rows.length ? gross / rows.length : 0;

  $("performanceDetailName").textContent = barber.name || "Barbero";
  $("performanceDetailPeriod").textContent = period.label;
  $("performanceDetailGross").textContent = money(gross);
  $("performanceDetailPay").textContent = money(pay);
  $("performanceDetailServices").textContent = rows.length;
  $("performanceDetailAverage").textContent = money(average);
  $("performanceDetailCount").textContent = `${rows.length} movimiento${rows.length===1?"":"s"}`;

  $("performanceDetailRows").innerHTML = rows.length ? rows.map(s => `
    <tr>
      <td>${fmtDateTime(s.date)}</td>
      <td><b>${escapeHtml(s.serviceName || "Servicio")}</b></td>
      <td>${escapeHtml(s.payment || "—")}</td>
      <td>${money(s.total)}</td>
      <td class="money-positive"><b>${money(s.barberAmount)}</b></td>
    </tr>
  `).join("") : `<tr><td colspan="5" class="empty">No hay movimientos para ${escapeHtml(period.label)}.</td></tr>`;

  openModal("barberPerformanceDetailModal");
}

function printBarberPerformanceReport() {
  if (!currentPerformanceBarberId) return toast("Selecciona un barbero primero.");
  const barber = state.barbers.find(b => b.id === currentPerformanceBarberId);
  if (!barber) return toast("No se encontró el barbero.");
  const period = dashboardPeriod();
  const rows = state.sales
    .filter(s => s.barberId === barber.id && saleInDashboardPeriod(s, period))
    .sort((a,b)=>jsDate(a.date)-jsDate(b.date));
  const gross = rows.reduce((sum,s)=>sum+Number(s.total||0),0);
  const pay = rows.reduce((sum,s)=>sum+Number(s.barberAmount||0),0);
  const average = rows.length ? gross / rows.length : 0;
  const generatedAt = new Date().toLocaleString("es-PA", {dateStyle:"long",timeStyle:"short"});
  const details = rows.map((s,index)=>`
    <tr><td>${index+1}</td><td>${receiptSafeText(fmtDateTime(s.date))}</td><td>${receiptSafeText(s.serviceName||"Servicio")}</td><td>${receiptSafeText(s.payment||"—")}</td><td class="num">${receiptSafeText(money(s.total))}</td><td class="num pay">${receiptSafeText(money(s.barberAmount))}</td></tr>`).join("");

  const printWindow = window.open("", "_blank", "width=1100,height=850");
  if (!printWindow) return toast("Tu navegador bloqueó la ventana de impresión.");
  printWindow.document.write(`<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Rendimiento - ${receiptSafeText(barber.name)}</title><style>
  *{box-sizing:border-box}body{margin:0;background:#fff;color:#222;font-family:Arial,Helvetica,sans-serif}.page{max-width:1000px;margin:0 auto;padding:24px}.head{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:14px;border-bottom:2px solid #c9a04d}.brand{display:flex;gap:13px;align-items:center}.logo{width:50px;height:50px;border-radius:12px;background:#e8d39f;display:grid;place-items:center;font-weight:900;font-size:20px;color:#51380b}.head h1{margin:0;font-size:25px}.sub{margin:4px 0 0;color:#75581f;text-transform:uppercase;font-size:10px;letter-spacing:.9px}.doc{text-align:right}.doc h2{margin:0;font-size:19px}.doc p{margin:5px 0 0;color:#666;font-size:10px}.meta{display:grid;grid-template-columns:1fr 1fr;gap:10px 18px;margin:18px 0;border:1px solid #e3ded3;border-radius:10px;padding:13px}.meta div{display:flex;justify-content:space-between;gap:12px}.meta span{color:#777}.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:16px 0}.kpi{border:1px solid #ddd8ce;border-radius:10px;padding:12px}.kpi.gold{background:#f4e5bf;border-color:#d3ad60}.kpi span{display:block;color:#76674d;font-size:9px;text-transform:uppercase;letter-spacing:.6px}.kpi strong{display:block;margin-top:5px;font-size:19px}.section-title{margin:20px 0 8px;font-size:12px;text-transform:uppercase;letter-spacing:.8px;color:#755512}table{width:100%;border-collapse:collapse;font-size:10px}th{background:#232323;color:#fff;text-align:left;padding:8px;font-size:9px;text-transform:uppercase}td{padding:8px;border-bottom:1px solid #e6e1d8}.num{text-align:right;white-space:nowrap}.pay{font-weight:700;color:#7a5814}.footer{margin-top:28px;padding-top:10px;border-top:1px solid #ddd;color:#777;text-align:center;font-size:9px}.print-note{text-align:center;color:#666;font-size:10px;margin-bottom:10px}@media print{.print-note{display:none}.page{padding:0}@page{size:A4;margin:10mm}}
  </style></head><body><div class="print-note">En la ventana de impresión selecciona <b>Guardar como PDF</b>.</div><main class="page">
  <header class="head"><div class="brand"><div class="logo">LM</div><div><h1>Barbería Los Mágicos</h1><p class="sub">Reporte individual de rendimiento</p></div></div><div class="doc"><h2>${receiptSafeText(barber.name)}</h2><p>${receiptSafeText(period.label)}</p><p>Generado: ${receiptSafeText(generatedAt)}</p></div></header>
  <section class="meta"><div><span>Barbero</span><strong>${receiptSafeText(barber.name)}</strong></div><div><span>Puesto</span><strong>${receiptSafeText(barber.chairName||"Sin puesto")}</strong></div><div><span>Período</span><strong>${receiptSafeText(period.label)}</strong></div><div><span>Estado</span><strong>${barber.active===false?"Inactivo":"Activo"}</strong></div></section>
  <section class="kpis"><div class="kpi"><span>Producción total</span><strong>${receiptSafeText(money(gross))}</strong></div><div class="kpi gold"><span>Ganancia barbero</span><strong>${receiptSafeText(money(pay))}</strong></div><div class="kpi"><span>Servicios</span><strong>${rows.length}</strong></div><div class="kpi"><span>Promedio</span><strong>${receiptSafeText(money(average))}</strong></div></section>
  <h3 class="section-title">Detalle de movimientos</h3><table><thead><tr><th>#</th><th>Fecha / hora</th><th>Servicio</th><th>Método</th><th class="num">Total</th><th class="num">Pago barbero</th></tr></thead><tbody>${details || `<tr><td colspan="6">Sin movimientos en el período seleccionado.</td></tr>`}</tbody></table>
  <footer class="footer">Barbería Los Mágicos · Reporte generado por el sistema de gestión</footer></main><script>window.addEventListener('load',()=>setTimeout(()=>window.print(),250));</script></body></html>`);
  printWindow.document.close();
}

function renderDashboardChairCards(periodSales = [], period = dashboardPeriod()) {
  const node = $("dashboardChairCards");
  if (!node) return;
  const singleToday = period.start === isoDay() && period.end === isoDay();

  node.innerHTML = state.chairs.map((chair,index) => {
    const sales = periodSales.filter(s => s.chairId === chair.id);
    const total = sales.reduce((a,s)=>a+Number(s.total||0),0);
    const barberPay = sales.reduce((a,s)=>a+Number(s.barberAmount||0),0);
    const shopPay = sales.reduce((a,s)=>a+Number(s.shopAmount||0),0);
    const assigned = state.barbers.filter(b => b.chairId === chair.id && b.active !== false);

    return `
      <article class="dashboard-chair-card">
        <div class="dashboard-chair-top">
          <div>
            <span class="card-kicker">PUESTO ${String(index+1).padStart(2,"0")}</span>
            <h4>${escapeHtml(chair.name)}</h4>
          </div>
          <div class="dashboard-chair-total"><span>${singleToday ? "GENERADO HOY" : "GENERADO PERÍODO"}</span><strong>${money(total)}</strong></div>
        </div>

        <div class="dashboard-chair-barber ${assigned.length ? "" : "empty-barber"}">
          <span class="dashboard-chair-avatar">${assigned.length ? escapeHtml((assigned[0].name||"B").charAt(0).toUpperCase()) : "—"}</span>
          <div>
            <small>BARBERO ASIGNADO</small>
            <strong>${assigned.length ? assigned.map(b=>escapeHtml(b.name)).join(", ") : "Sin barbero asignado"}</strong>
          </div>
        </div>

        <div class="dashboard-chair-money">
          <div><span>Barbero</span><strong>${money(barberPay)}</strong></div>
          <div><span>Barbería</span><strong>${money(shopPay)}</strong></div>
          <div><span>Servicios</span><strong>${sales.length}</strong></div>
        </div>

        <button class="chair-detail-btn" type="button" data-chair-day-detail="${chair.id}">
          Ver detalle ${singleToday ? "del día" : "del período"} →
        </button>
      </article>`;
  }).join("");

  document.querySelectorAll("[data-chair-day-detail]").forEach(btn =>
    btn.addEventListener("click", () => openChairDayDetail(btn.dataset.chairDayDetail))
  );
}

function openChairDayDetail(chairId) {
  const chair = state.chairs.find(c => c.id === chairId);
  if (!chair) return;

  const period = dashboardPeriod();
  const rows = state.sales
    .filter(s => s.chairId === chairId && saleInDashboardPeriod(s, period))
    .sort((a,b)=>jsDate(b.date)-jsDate(a.date));

  const assigned = state.barbers.filter(b => b.chairId === chairId);
  const total = rows.reduce((a,s)=>a+Number(s.total||0),0);
  const barberPay = rows.reduce((a,s)=>a+Number(s.barberAmount||0),0);
  const shopPay = rows.reduce((a,s)=>a+Number(s.shopAmount||0),0);
  const singleToday = period.start === isoDay() && period.end === isoDay();

  $("chairDayDetailTitle").textContent = chair.name;
  $("chairDayDetailSubtitle").textContent = `${assigned.length ? assigned.map(b=>b.name).join(", ") : "Sin barbero asignado"} · ${period.label}`;
  $("chairDayDetailTotal").textContent = money(total);
  if ($("chairDetailEyebrow")) $("chairDetailEyebrow").textContent = singleToday ? "DETALLE DEL DÍA" : "DETALLE DEL PERÍODO";
  if ($("chairDetailTotalLabel")) $("chairDetailTotalLabel").textContent = singleToday ? "TOTAL HOY" : "TOTAL PERÍODO";

  $("chairDayDetailSummary").innerHTML = `
    <div><span>Servicios</span><strong>${rows.length}</strong></div>
    <div><span>Pago barbero</span><strong>${money(barberPay)}</strong></div>
    <div><span>Ingreso barbería</span><strong>${money(shopPay)}</strong></div>
  `;

  $("chairDayDetailRows").innerHTML = rows.length ? rows.map(s => `
    <tr>
      <td>${fmtDateTime(s.date)}</td>
      <td>${escapeHtml(s.serviceName || "Servicio")}</td>
      <td>${escapeHtml(s.barberName || "")}</td>
      <td>${escapeHtml(s.payment || "")}</td>
      <td><b>${money(s.total)}</b></td>
      <td class="money-positive">${money(s.barberAmount)}</td>
      <td>${money(s.shopAmount)}</td>
    </tr>
  `).join("") : `<tr><td colspan="7" class="empty">No hay movimientos para este puesto en ${escapeHtml(period.label)}.</td></tr>`;

  currentChairReceiptContext = {
    chair,
    period,
    rows,
    assigned,
    total,
    barberPay,
    shopPay
  };

  openModal("chairDayDetailModal");
}

function receiptSafeText(value) {
  return escapeHtml(value ?? "");
}

function printChairPaymentReceipt() {
  const ctx = currentChairReceiptContext;
  if (!ctx?.chair) return toast("Abre primero el detalle de un puesto.");
  if (!ctx.rows?.length) return toast("No hay movimientos en este período para generar un comprobante.");

  const { chair, period, rows, assigned, barberPay } = ctx;
  const saleBarberNames = [...new Set(rows.map(s => String(s.barberName || "").trim()).filter(Boolean))];
  const assignedNames = assigned.map(b => String(b.name || "").trim()).filter(Boolean);
  const barberNames = saleBarberNames.length ? saleBarberNames : assignedNames;
  const barberName = barberNames.length ? barberNames.join(", ") : "Barbero";
  const adminName = currentAdmin?.name || "Administrador";
  const periodCode = period.start === period.end
    ? period.start.replaceAll("-","")
    : `${period.start.replaceAll("-","")}-${period.end.replaceAll("-","")}`;
  const chairCode = String(chair.name || chair.id || "PUESTO").toUpperCase().replace(/[^A-Z0-9]+/g,"-").replace(/^-|-$/g,"");
  const receiptNo = `LM-${chairCode || "PUESTO"}-${periodCode}`;
  const generatedAt = new Date().toLocaleString("es-PA", {
    day:"2-digit", month:"long", year:"numeric", hour:"2-digit", minute:"2-digit"
  });
  const singleDay = period.start === period.end;

  const detailRows = rows.map((s,index) => `
    <tr>
      <td>${index+1}</td>
      <td>${receiptSafeText(fmtDateTime(s.date))}</td>
      <td>${receiptSafeText(s.serviceName || "Servicio")}</td>
      <td>${receiptSafeText(s.payment || "—")}</td>
      <td class="num barber-pay">${receiptSafeText(money(s.barberAmount))}</td>
    </tr>
  `).join("");

  const printWindow = window.open("", "_blank", "width=1000,height=820");
  if (!printWindow) return toast("El navegador bloqueó la ventana de impresión. Permite ventanas emergentes e inténtalo otra vez.");

  printWindow.document.open();
  printWindow.document.write(`<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Comprobante de pago - ${receiptSafeText(receiptNo)}</title>
<style>
  @page{size:A4;margin:14mm}
  *{box-sizing:border-box}
  body{margin:0;background:#f4f1ea;color:#171717;font-family:Arial,Helvetica,sans-serif;font-size:12px}
  .page{width:100%;max-width:190mm;margin:0 auto;background:#fff;padding:18px 20px;border:1px solid #ddd7ca}
  .head{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;border-bottom:2px solid #c59a45;padding-bottom:14px}
  .brand{display:flex;gap:12px;align-items:center}
  .logo{width:48px;height:48px;border-radius:12px;background:#d5aa54;display:grid;place-items:center;font-family:Georgia,serif;font-size:20px;font-weight:700;color:#17120b}
  .brand h1{margin:0;font-family:Georgia,serif;font-size:24px}.brand p{margin:4px 0 0;color:#666;font-size:10px;letter-spacing:.8px;text-transform:uppercase}
  .doc{text-align:right}.doc h2{margin:0;font-size:17px}.doc p{margin:4px 0;color:#666;font-size:10px}.receipt-no{font-weight:700;color:#8b651e}
  .intro{margin:17px 0 12px;padding:12px 14px;border:1px solid #e4dfd5;background:#faf8f3;border-radius:8px}
  .meta{display:grid;grid-template-columns:repeat(2,1fr);gap:8px 18px}.meta div{display:grid;grid-template-columns:105px 1fr;gap:8px}.meta span{color:#777}.meta strong{font-weight:700}
  .summary{display:grid;grid-template-columns:minmax(260px,420px);justify-content:center;gap:10px;margin:18px 0}.sum{border:1px solid #e1ddd4;border-radius:8px;padding:12px}.sum span{display:block;color:#777;font-size:9px;text-transform:uppercase;letter-spacing:.7px}.sum strong{display:block;margin-top:5px;font-size:17px}.sum.primary{background:#f4e4bd;border-color:#d7b66e}.sum.primary strong{font-size:21px;color:#5f430d}
  .section-title{margin:18px 0 8px;font-size:12px;text-transform:uppercase;letter-spacing:.9px;color:#775511}
  table{width:100%;border-collapse:collapse;font-size:10px}th{background:#222;color:#fff;text-align:left;padding:8px 7px;font-size:9px;text-transform:uppercase;letter-spacing:.5px}td{padding:8px 7px;border-bottom:1px solid #e6e2da;vertical-align:top}.num{text-align:right;white-space:nowrap}.barber-pay{font-weight:700;color:#775511}
  .ack{margin:18px 0 28px;padding:12px 14px;border-left:4px solid #c59a45;background:#faf8f3;line-height:1.5;color:#444}
  .signatures{display:grid;grid-template-columns:1fr 1fr;gap:55px;margin-top:54px}.sig{text-align:center}.line{border-top:1px solid #222;padding-top:7px;font-weight:700}.sig small{display:block;color:#666;margin-top:4px}.sig .name{margin-top:5px;color:#333;font-size:10px}
  .footer{margin-top:34px;padding-top:9px;border-top:1px solid #ddd;text-align:center;color:#777;font-size:9px}
  .print-note{margin:0 0 10px;text-align:center;color:#666;font-size:10px}
  @media print{body{background:#fff}.page{border:0;padding:0}.print-note{display:none}}
</style>
</head>
<body>
  <div class="print-note">En la ventana de impresión puedes elegir <b>Guardar como PDF</b>.</div>
  <main class="page">
    <header class="head">
      <div class="brand">
        <div class="logo">LM</div>
        <div><h1>Barbería Los Mágicos</h1><p>Comprobante de pago al barbero</p></div>
      </div>
      <div class="doc">
        <h2>${singleDay ? "Comprobante diario" : "Comprobante del período"}</h2>
        <p class="receipt-no">No. ${receiptSafeText(receiptNo)}</p>
        <p>Generado: ${receiptSafeText(generatedAt)}</p>
      </div>
    </header>

    <section class="intro">
      <div class="meta">
        <div><span>Barbero:</span><strong>${receiptSafeText(barberName)}</strong></div>
        <div><span>Puesto:</span><strong>${receiptSafeText(chair.name)}</strong></div>
        <div><span>${singleDay ? "Fecha:" : "Período:"}</span><strong>${receiptSafeText(period.label)}</strong></div>
        <div><span>Administrador:</span><strong>${receiptSafeText(adminName)}</strong></div>
      </div>
    </section>

    <section class="summary">
      <div class="sum primary"><span>Monto a pagar al barbero</span><strong>${receiptSafeText(money(barberPay))}</strong><small>${rows.length} movimiento${rows.length===1?"":"s"} incluido${rows.length===1?"":"s"}</small></div>
    </section>

    <h3 class="section-title">Detalle de movimientos</h3>
    <table>
      <thead><tr><th>#</th><th>Fecha / Hora</th><th>Servicio</th><th>Método</th><th class="num">Pago al barbero</th></tr></thead>
      <tbody>${detailRows}</tbody>
    </table>

    <div class="ack">
      Con las firmas al pie, ambas partes dejan constancia de que <b>Barbería Los Mágicos entrega al barbero la suma de ${receiptSafeText(money(barberPay))}</b>, correspondiente exclusivamente a los movimientos detallados en este comprobante para ${receiptSafeText(period.label)}.
    </div>

    <section class="signatures">
      <div class="sig">
        <div class="line">Firma Barbería / Administrador</div>
        <div class="name">${receiptSafeText(adminName)} · Barbería Los Mágicos</div>
        <small>Fecha de firma: __________________</small>
      </div>
      <div class="sig">
        <div class="line">Firma Barbero</div>
        <div class="name">${receiptSafeText(barberName)}</div>
        <small>Fecha de firma: __________________</small>
      </div>
    </section>

    <footer class="footer">Barbería Los Mágicos · Comprobante generado por el sistema de gestión</footer>
  </main>
<script>
  window.addEventListener('load',()=>setTimeout(()=>window.print(),250));
</script>
</body>
</html>`);
  printWindow.document.close();
}

function renderSales() {
  const rows = [...state.sales].sort((a,b)=>jsDate(b.date)-jsDate(a.date));
  if ($("salesHistoryCount")) $("salesHistoryCount").textContent = rows.length;
  $("salesTable").innerHTML = rows.length ? rows.map(s => `
    <tr><td>${fmtDateTime(s.date)}</td><td>${escapeHtml(s.barberName)}</td><td>${escapeHtml(s.chairName)}</td><td>${escapeHtml(s.serviceName)}</td><td>${escapeHtml(s.payment)}</td><td><b>${money(s.total)}</b></td><td>${money(s.barberAmount)}</td><td>${money(s.shopAmount)}</td></tr>
  `).join("") : `<tr><td colspan="8" class="empty">No hay cobros registrados.</td></tr>`;
}



async function exportApprovedSalesExcel() {
  if (currentRole !== "admin") return toast("Solo el administrador puede exportar este historial.");
  if (!state.sales.length) return toast("No hay cobros aprobados para exportar.");
  if (!window.ExcelJS) return toast("No se pudo cargar el generador de Excel. Revisa tu conexión a Internet.");

  try {
    const rows = [...state.sales].sort((a,b)=>jsDate(b.date)-jsDate(a.date));
    const ExcelJS = window.ExcelJS;
    const wb = new ExcelJS.Workbook();
    wb.creator = "Barbería Los Mágicos";
    wb.title = "Cobros aprobados";
    wb.created = new Date();

    const ws = wb.addWorksheet("Cobros aprobados", {
      views:[{state:"frozen", ySplit:5}],
      pageSetup:{orientation:"landscape", fitToPage:true, fitToWidth:1}
    });

    ws.mergeCells("A1:H2");
    const brand = ws.getCell("A1");
    brand.value = "BARBERÍA LOS MÁGICOS";
    brand.font = {name:"Aptos Display", size:22, bold:true, color:{argb:"FFD7AD56"}};
    brand.fill = {type:"pattern",pattern:"solid",fgColor:{argb:"FF111114"}};
    brand.alignment = {vertical:"middle",horizontal:"left"};

    ws.mergeCells("A3:H3");
    ws.getCell("A3").value = "Historial de cobros aprobados";
    ws.getCell("A3").font = {name:"Aptos", size:14, bold:true};

    ws.mergeCells("A4:H4");
    ws.getCell("A4").value = `Exportado el ${new Date().toLocaleString("es-PA")} · ${rows.length} movimientos`;
    ws.getCell("A4").font = {name:"Aptos", size:9, color:{argb:"FF666666"}};

    const headers = ["Fecha","Barbero","Puesto","Servicio","Método","Total","Pago barbero","Ingreso barbería"];
    headers.forEach((h,i)=>ws.getCell(5,i+1).value=h);
    ws.getRow(5).eachCell(cell => {
      cell.fill = {type:"pattern",pattern:"solid",fgColor:{argb:"FF1D1D21"}};
      cell.font = {bold:true,color:{argb:"FFFFFFFF"}};
      cell.alignment = {vertical:"middle",horizontal:"center"};
    });

    rows.forEach((s,idx)=>{
      const r = 6 + idx;
      ws.getCell(r,1).value = jsDate(s.date);
      ws.getCell(r,1).numFmt = "dd-mmm-yyyy hh:mm";
      ws.getCell(r,2).value = s.barberName || "";
      ws.getCell(r,3).value = s.chairName || "";
      ws.getCell(r,4).value = s.serviceName || "";
      ws.getCell(r,5).value = s.payment || "";
      ws.getCell(r,6).value = Number(s.total || 0);
      ws.getCell(r,7).value = Number(s.barberAmount || 0);
      ws.getCell(r,8).value = Number(s.shopAmount || 0);
      [6,7,8].forEach(c => ws.getCell(r,c).numFmt = '$#,##0.00');
      ws.getRow(r).eachCell(cell => {
        cell.border = {bottom:{style:"hair",color:{argb:"FFE3E3E3"}}};
        cell.alignment = {vertical:"middle"};
      });
    });

    ws.columns = [
      {width:23},{width:25},{width:18},{width:28},
      {width:16},{width:16},{width:18},{width:18}
    ];
    ws.autoFilter = {from:"A5",to:"H5"};

    const buffer = await wb.xlsx.writeBuffer();
    const blob = new Blob([buffer], {type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Barberia_Los_Magicos_Cobros_Aprobados_${isoDay()}.xlsx`;
    a.click();
    URL.revokeObjectURL(url);
    toast("Historial exportado a Excel.");
  } catch (err) {
    console.error(err);
    toast("No se pudo generar el Excel del historial.");
  }
}


function renderPendingChargeRequests() {
  if (currentRole !== "admin") return;

  const pending = state.chargeRequests
    .filter(r => r.status === "pending")
    .sort((a,b) => jsDate(a.requestedAt) - jsDate(b.requestedAt));

  $("pendingCashCount").textContent = pending.length;

  $("pendingChargeRequests").innerHTML = pending.length ? pending.map(r => `
    <article class="cash-request-card">
      <div class="cash-request-top">
        <div class="cash-avatar">${escapeHtml((r.barberName || "B").charAt(0).toUpperCase())}</div>
        <div class="cash-request-person">
          <span class="cash-label">BARBERO</span>
          <h4>${escapeHtml(r.barberName || "Barbero")}</h4>
          <small>${r.requestedAt ? fmtDateTime(r.requestedAt) : "Enviado ahora"}</small>
        </div>
        <span class="request-status pending">POR CONFIRMAR</span>
      </div>

      <div class="cash-request-service">
        <span>Servicio realizado</span>
        <strong>${escapeHtml(r.serviceName || "Servicio")}</strong>
        <small>${escapeHtml(r.chairName || "Sin puesto")}</small>
      </div>

      ${Array.isArray(r.products) && r.products.length ? `
      <div class="cash-request-products">
        <span class="cash-label">PRODUCTOS VENDIDOS</span>
        ${r.products.map(p => `
          <div class="cash-product-row">
            <span>${Number(p.qty || 0)}× ${escapeHtml(p.name || "Producto")}</span>
            <strong>${money(p.subtotal || (Number(p.unitPrice||0)*Number(p.qty||0)))}</strong>
          </div>
        `).join("")}
        <div class="cash-product-subtotal"><span>Subtotal productos</span><strong>${money(r.productTotal || 0)}</strong></div>
      </div>` : ""}

      <div class="cash-request-price">
        <span>TOTAL ENVIADO POR EL BARBERO</span>
        <strong>${money(r.price)}</strong>
        <small>Servicio ${money(r.servicePrice ?? (Number(r.price||0)-Number(r.productTotal||0)))} + productos ${money(r.productTotal||0)}</small>
      </div>

      <div class="cash-confirm-summary">
        <div>
          <span>Método de pago</span>
          <strong>${escapeHtml(r.payment || "No indicado")}</strong>
        </div>
        <div>
          <span>Comisión servicio</span>
          <strong>${Number(r.serviceCommissionPreview ?? r.commissionPreview ?? 50)}%</strong>
        </div>
        <div>
          <span>Comisión productos</span>
          <strong>${Number(r.productCommissionPreview ?? 0)}%</strong>
        </div>
      </div>

      ${r.note ? `<div class="cash-note">“${escapeHtml(r.note)}”</div>` : ""}

      <div class="cash-admin-message">
        <span>✓</span>
        <p>El barbero ya definió el cobro. Solo confirma que el trabajo fue realizado y que el cliente pagó.</p>
      </div>

      <div class="cash-actions cash-actions-full">
        <button class="cash-reject-btn" data-reject-charge="${r.id}" type="button">Rechazar</button>
        <button class="cash-approve-btn" data-approve-charge="${r.id}" type="button">Confirmar trabajo y cobro →</button>
      </div>
    </article>
  `).join("") : `<div class="cash-empty"><span>✓</span><strong>Todo confirmado</strong><p>No hay cobros pendientes enviados por los barberos.</p></div>`;

  document.querySelectorAll("[data-approve-charge]").forEach(btn =>
    btn.addEventListener("click", () => approveChargeRequest(btn.dataset.approveCharge))
  );
  document.querySelectorAll("[data-reject-charge]").forEach(btn =>
    btn.addEventListener("click", () => rejectChargeRequest(btn.dataset.rejectCharge))
  );
}

async function approveChargeRequest(requestId) {
  const requestRef = doc(db, "chargeRequests", requestId);
  const saleRef = doc(db, "sales", requestId);

  try {
    await runTransaction(db, async transaction => {
      const requestSnap = await transaction.get(requestRef);
      if (!requestSnap.exists()) throw new Error("Solicitud no encontrada");

      const request = requestSnap.data();
      if (request.status !== "pending") throw new Error("Esta solicitud ya fue procesada");

      const barberRef = doc(db, "users", request.barberId);
      const barberSnap = await transaction.get(barberRef);
      if (!barberSnap.exists()) throw new Error("Barbero no encontrado");

      const barber = barberSnap.data();
      if (barber.active === false || barber.role !== "barber") throw new Error("Barbero inactivo");

      const requestedProducts = Array.isArray(request.products) ? request.products : [];
      const productStockUpdates = [];
      for (const item of requestedProducts) {
        const productRef = doc(db, "products", item.productId);
        const productSnap = await transaction.get(productRef);
        if (!productSnap.exists()) throw new Error(`Producto no encontrado: ${item.name || "Producto"}`);
        const productData = productSnap.data();
        const availableStock = Math.max(0, Number(productData.stock || 0));
        const soldQty = Math.max(0, Number(item.qty || 0));
        if (soldQty > availableStock) {
          throw new Error(`STOCK:${productData.name || item.name || "Producto"}:${availableStock}`);
        }
        productStockUpdates.push({ ref:productRef, stock:availableStock - soldQty });
      }

      const servicePrice = Number(
        request.servicePrice ??
        (Number(request.price || 0) - Number(request.productTotal || 0))
      );
      const productTotal = Number(request.productTotal || 0);
      const total = +(servicePrice + productTotal).toFixed(2);

      if (servicePrice <= 0 || total <= 0) throw new Error("Precio inválido");

      const payment = request.payment || "Efectivo";

      // Comisiones independientes configuradas por el administrador.
      const serviceCommission = Number(barber.commission ?? 50);
      const productCommission = Number(barber.productCommission ?? 0);

      const serviceBarberAmount = +(servicePrice * serviceCommission / 100).toFixed(2);
      const productBarberAmount = +(productTotal * productCommission / 100).toFixed(2);
      const barberAmount = +(serviceBarberAmount + productBarberAmount).toFixed(2);

      const serviceShopAmount = +(servicePrice - serviceBarberAmount).toFixed(2);
      const productShopAmount = +(productTotal - productBarberAmount).toFixed(2);
      const shopAmount = +(serviceShopAmount + productShopAmount).toFixed(2);

      productStockUpdates.forEach(item => {
        transaction.update(item.ref, { stock:item.stock, updatedAt:serverTimestamp() });
      });

      transaction.set(saleRef, {
        date:serverTimestamp(),
        barberId:request.barberId,
        barberName:request.barberName || barber.name || "Barbero",
        chairId:request.chairId,
        chairName:request.chairName,

        serviceId:request.serviceId,
        serviceName:request.serviceName,
        servicePrice,

        products:Array.isArray(request.products) ? request.products : [],
        productTotal,

        payment,
        total,

        // Mantener commission por compatibilidad con reportes antiguos:
        commission:serviceCommission,

        serviceCommission,
        productCommission,
        serviceBarberAmount,
        productBarberAmount,
        barberAmount,
        serviceShopAmount,
        productShopAmount,
        shopAmount,

        note:request.note || "",
        createdBy:auth.currentUser.uid,
        source:"barber_request",
        requestId
      });

      transaction.update(requestRef, {
        status:"approved",
        payment,
        serviceCommission,
        productCommission,
        serviceBarberAmount,
        productBarberAmount,
        barberAmount,
        serviceShopAmount,
        productShopAmount,
        shopAmount,
        saleId:saleRef.id,
        approvedBy:auth.currentUser.uid,
        approvedAt:serverTimestamp()
      });
    });

    toast("Cobro confirmado. Las comisiones de servicio y productos fueron calculadas por separado.");
  } catch (err) {
    console.error(err);
    const msg = String(err?.message || "");
    if (msg.startsWith("STOCK:")) {
      const [,product,available] = msg.split(":");
      return toast(`Stock insuficiente de ${product}. Disponible: ${available}.`);
    }
    toast(firebaseErrorMessage(err, err?.message || "No se pudo aprobar el cobro."));
  }
}

async function rejectChargeRequest(requestId) {
  if (!confirm("¿Rechazar este trabajo enviado por el barbero? No se registrará la venta ni se acreditará comisión.")) return;
  try {
    await updateDoc(doc(db, "chargeRequests", requestId), {
      status:"rejected",
      rejectedBy:auth.currentUser.uid,
      rejectedAt:serverTimestamp()
    });
    toast("Cobro rechazado.");
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo rechazar el cobro."));
  }
}

async function saveSale(e) {
  e.preventDefault();
  const barber = state.barbers.find(x => x.id === $("saleBarber").value);
  const chair = state.chairs.find(x => x.id === $("saleChair").value);
  const service = state.services.find(x => x.id === $("saleService").value);
  const total = Number($("salePrice").value);

  if (!barber || !service || total <= 0) return toast("Revisa los datos del cobro.");
  if (!chair) return toast("Ese barbero no tiene puesto fijo asignado.");

  try {
    const commission = Number(barber.commission ?? 50);
    const barberAmount = +(total * commission / 100).toFixed(2);

    await setDoc(doc(collection(db, "sales")), {
      date:serverTimestamp(),
      barberId:barber.id,
      barberName:barber.name,
      chairId:chair.id,
      chairName:chair.name,
      serviceId:service.id,
      serviceName:service.name,
      payment:$("salePayment").value,
      total,
      commission,
      barberAmount,
      shopAmount:+(total-barberAmount).toFixed(2),
      note:$("saleNote").value.trim(),
      createdBy:auth.currentUser.uid
    });

    closeModal("saleModal");
    e.target.reset();
    toast("Cobro registrado.");
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo registrar el cobro."));
  }
}


function appointmentNeedsBarber(a) {
  return !a.barberId || a.barberId === "unassigned" || a.needsAssignment === true;
}

function barberIsFreeForAppointment(barberId, appointment) {
  const targetSlotId = slotId(barberId, appointment.date, appointment.time);
  return !state.bookedSlots.some(s =>
    s.id === targetSlotId &&
    s.status !== "cancelled" &&
    s.id !== appointment.slotId
  );
}

function assignmentOptionsForAppointment(appointment) {
  const available = state.barbers.filter(b =>
    b.active !== false && barberIsFreeForAppointment(b.id, appointment)
  );
  return `<option value="">Selecciona barbero...</option>` +
    available.map(b => `<option value="${b.id}">${escapeHtml(b.name)} · ${escapeHtml(b.chairName || "Puesto sin asignar")}</option>`).join("");
}

function openDashboardAppointmentsModal() {
  const period = dashboardPeriod();
  renderAdminAppointmentsModal(period, false);
  openModal("todayAppointmentsModal");
}

function renderAdminAppointmentsModal(period, forceToday = false) {
  const node = $("todayAppointmentsModalList");
  if (!node || currentRole !== "admin") return;

  const p = forceToday ? { start:isoDay(), end:isoDay(), label:shortDayLabel(isoDay()) } : period;
  const rows = state.appointments
    .filter(a => dateKeyInPeriod(a.date, p) && !["completed","cancelled"].includes(a.status))
    .sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));

  const singleToday = p.start === isoDay() && p.end === isoDay();
  $("todayAppointmentsModalCount").textContent = rows.length;
  $("todayAppointmentsDateLabel").textContent = singleToday
    ? new Date().toLocaleDateString("es-PA", { weekday:"long", day:"2-digit", month:"long", year:"numeric" })
    : p.label;
  if ($("adminAppointmentsModalEyebrow")) $("adminAppointmentsModalEyebrow").textContent = singleToday ? "AGENDA DE HOY" : "AGENDA DEL PERÍODO";
  if ($("adminAppointmentsModalTitle")) $("adminAppointmentsModalTitle").textContent = singleToday ? "Citas del día" : "Citas del período";

  node.innerHTML = rows.length ? rows.map(a => `
    <article class="today-appt-card ${appointmentNeedsBarber(a) ? "needs-barber" : ""}">
      <div class="today-appt-time">
        <span>${singleToday ? "HORA" : fmtDateOnly(a.date)}</span><strong>${escapeHtml(a.time || "")}</strong>
      </div>
      <div class="today-appt-main">
        <div class="today-appt-client">
          <span class="status ${a.status}">${statusLabel(a.status)}</span>
          <h4>${escapeHtml(a.clientName || "Cliente")}</h4>
          <small>${escapeHtml(a.clientPhone || "")} · ${escapeHtml(a.serviceName || "")}</small>
        </div>

        ${appointmentNeedsBarber(a) ? `
          <div class="today-assign-box">
            <div><span>BARBERO</span><strong>Por asignar</strong></div>
            <select data-assign-select="${a.id}">${assignmentOptionsForAppointment(a)}</select>
            <button class="primary-btn tiny-assignment-btn" type="button" data-assign-appt="${a.id}">Asignar</button>
          </div>
        ` : `
          <div class="today-assigned-barber">
            <span>BARBERO</span>
            <strong>${escapeHtml(a.barberName || "Barbero")}</strong>
          </div>
        `}
      </div>
      <div class="today-appt-actions">
        ${a.status==="pending" ? `<button class="tiny-btn" data-today-appt="${a.id}" data-status="confirmed" type="button">Confirmar</button>` : ""}
        ${a.status==="confirmed" ? `<button class="tiny-btn" data-today-appt="${a.id}" data-status="completed" type="button">Completar</button>` : ""}
        ${!["completed","cancelled"].includes(a.status) ? `<button class="tiny-btn danger" data-today-appt="${a.id}" data-status="cancelled" type="button">Cancelar</button>` : ""}
      </div>
    </article>
  `).join("") : `<div class="cash-empty"><span>◷</span><strong>Sin citas</strong><p>No hay citas registradas en ${escapeHtml(p.label)}.</p></div>`;

  document.querySelectorAll("[data-assign-appt]").forEach(btn =>
    btn.addEventListener("click", () => {
      const select = document.querySelector(`[data-assign-select="${btn.dataset.assignAppt}"]`);
      assignBarberToAppointment(btn.dataset.assignAppt, select?.value || "");
    })
  );

  document.querySelectorAll("[data-today-appt]").forEach(btn =>
    btn.addEventListener("click", () => changeAppointment(btn.dataset.todayAppt, btn.dataset.status))
  );
}

function openTodayAppointmentsModal() {
  renderAdminAppointmentsModal({ start:isoDay(), end:isoDay(), label:shortDayLabel(isoDay()) }, true);
  openModal("todayAppointmentsModal");
}

function renderTodayAppointmentsModal() {
  const node = $("todayAppointmentsModalList");
  if (!node || currentRole !== "admin") return;

  const today = state.appointments
    .filter(a => a.date === isoDay() && !["completed","cancelled"].includes(a.status))
    .sort((a,b)=>(a.time||"").localeCompare(b.time||""));

  $("todayAppointmentsModalCount").textContent = today.length;
  $("todayAppointmentsDateLabel").textContent = new Date().toLocaleDateString("es-PA", {
    weekday:"long", day:"2-digit", month:"long", year:"numeric"
  });

  node.innerHTML = today.length ? today.map(a => `
    <article class="today-appt-card ${appointmentNeedsBarber(a) ? "needs-barber" : ""}">
      <div class="today-appt-time">
        <span>HORA</span><strong>${escapeHtml(a.time || "")}</strong>
      </div>
      <div class="today-appt-main">
        <div class="today-appt-client">
          <span class="status ${a.status}">${statusLabel(a.status)}</span>
          <h4>${escapeHtml(a.clientName || "Cliente")}</h4>
          <small>${escapeHtml(a.clientPhone || "")} · ${escapeHtml(a.serviceName || "")}</small>
        </div>

        ${appointmentNeedsBarber(a) ? `
          <div class="today-assign-box">
            <div><span>BARBERO</span><strong>Por asignar</strong></div>
            <select data-assign-select="${a.id}">${assignmentOptionsForAppointment(a)}</select>
            <button class="primary-btn tiny-assignment-btn" type="button" data-assign-appt="${a.id}">Asignar</button>
          </div>
        ` : `
          <div class="today-assigned-barber">
            <span>BARBERO</span>
            <strong>${escapeHtml(a.barberName || "Barbero")}</strong>
          </div>
        `}
      </div>
      <div class="today-appt-actions">
        ${a.status==="pending" ? `<button class="tiny-btn" data-today-appt="${a.id}" data-status="confirmed" type="button">Confirmar</button>` : ""}
        ${a.status==="confirmed" ? `<button class="tiny-btn" data-today-appt="${a.id}" data-status="completed" type="button">Completar</button>` : ""}
        ${!["completed","cancelled"].includes(a.status) ? `<button class="tiny-btn danger" data-today-appt="${a.id}" data-status="cancelled" type="button">Cancelar</button>` : ""}
      </div>
    </article>
  `).join("") : `<div class="cash-empty"><span>◷</span><strong>Agenda libre</strong><p>No hay citas registradas para hoy.</p></div>`;

  document.querySelectorAll("[data-assign-appt]").forEach(btn =>
    btn.addEventListener("click", () => {
      const select = document.querySelector(`[data-assign-select="${btn.dataset.assignAppt}"]`);
      assignBarberToAppointment(btn.dataset.assignAppt, select?.value || "");
    })
  );

  document.querySelectorAll("[data-today-appt]").forEach(btn =>
    btn.addEventListener("click", () => changeAppointment(btn.dataset.todayAppt, btn.dataset.status))
  );
}

async function assignBarberToAppointment(appointmentId, barberId) {
  if (!barberId) return toast("Selecciona un barbero.");

  const barber = state.barbers.find(b => b.id === barberId && b.active !== false);
  const localAppt = state.appointments.find(a => a.id === appointmentId);
  if (!barber || !localAppt) return toast("No se encontró la cita o el barbero.");

  const newSlotId = slotId(barber.id, localAppt.date, localAppt.time);
  const newSlotRef = doc(db, "bookedSlots", newSlotId);
  const apptRef = doc(db, "appointments", appointmentId);

  try {
    await runTransaction(db, async tx => {
      const apptSnap = await tx.get(apptRef);
      if (!apptSnap.exists()) throw new Error("Cita no encontrada");

      const appt = apptSnap.data();
      const oldSlotId = appt.slotId || appointmentId;
      const oldSlotRef = doc(db, "bookedSlots", oldSlotId);

      const newSlotSnap = await tx.get(newSlotRef);
      if (
        newSlotId !== oldSlotId &&
        newSlotSnap.exists() &&
        newSlotSnap.data().status !== "cancelled"
      ) {
        throw new Error("BARBER_BUSY");
      }

      if (newSlotId !== oldSlotId) {
        tx.delete(oldSlotRef);
        tx.set(newSlotRef, {
          slotId:newSlotId,
          ownerUid:appt.ownerUid,
          barberId:barber.id,
          date:appt.date,
          time:appt.time,
          status:appt.status || "pending",
          createdAt:appt.createdAt || serverTimestamp(),
          updatedAt:serverTimestamp()
        });
      } else {
        tx.set(newSlotRef, {
          barberId:barber.id,
          status:appt.status || "pending",
          updatedAt:serverTimestamp()
        }, { merge:true });
      }

      tx.update(apptRef, {
        barberId:barber.id,
        barberName:barber.name,
        reservedBarberId:barber.id,
        slotId:newSlotId,
        needsAssignment:false,
        assignedBy:auth.currentUser.uid,
        assignedAt:serverTimestamp(),
        updatedAt:serverTimestamp()
      });
    });

    toast(`${barber.name} fue asignado a la cita.`);
  } catch (err) {
    console.error(err);
    if (String(err?.message).includes("BARBER_BUSY")) {
      return toast("Ese barbero ya tiene una cita en ese horario. Selecciona otro.");
    }
    toast(firebaseErrorMessage(err, "No se pudo asignar el barbero."));
  }
}

function renderAppointments() {
  const filter = $("appointmentFilter").value;

  let rows = state.appointments
    .filter(a => !["completed","cancelled"].includes(a.status))
    .sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));

  if (filter !== "all") rows = rows.filter(x => x.status === filter);

  $("appointmentCards").innerHTML = rows.length ? rows.map(a => `
    <article class="appointment-card ${appointmentNeedsBarber(a) ? "appointment-needs-barber" : ""}">
      <div class="appointment-top">
        <div>
          <span class="status ${a.status}">${statusLabel(a.status)}</span>
          <h3>${escapeHtml(a.clientName)}</h3>
          <div class="card-meta">${escapeHtml(a.clientPhone)} · ${escapeHtml(a.serviceName)}</div>
        </div>
        <div class="appt-time">${a.time}</div>
      </div>

      <div class="card-meta" style="margin-top:12px">
        ${fmtDateOnly(a.date)} · ${appointmentNeedsBarber(a) ? "Por asignar" : escapeHtml(a.barberName)} · ${money(a.servicePrice)}
      </div>

      ${appointmentNeedsBarber(a) ? `
        <div class="appointment-assign-admin">
          <div><span>BARBERO PENDIENTE</span><strong>Asigna un barbero disponible</strong></div>
          <select data-full-assign-select="${a.id}">${assignmentOptionsForAppointment(a)}</select>
          <button class="primary-btn tiny-assignment-btn" data-full-assign="${a.id}" type="button">Asignar barbero</button>
        </div>
      ` : ""}

      ${a.note ? `<div class="credential">Nota: ${escapeHtml(a.note)}</div>` : ""}

      <div class="appt-actions">
        ${a.status==="pending" ? `<button class="tiny-btn" data-appt="${a.id}" data-status="confirmed" type="button">Confirmar</button>` : ""}
        ${a.status==="confirmed" ? `<button class="tiny-btn" data-appt="${a.id}" data-status="completed" type="button">Completar</button>` : ""}
        <button class="tiny-btn danger" data-appt="${a.id}" data-status="cancelled" type="button">Cancelar</button>
      </div>
    </article>
  `).join("") : `<div class="empty">No hay citas activas en esta categoría.</div>`;

  const completed = state.appointments
    .filter(a => a.status === "completed")
    .sort((a,b)=>(b.date+b.time).localeCompare(a.date+a.time));

  const completedNode = $("completedAppointmentsRows");
  if (completedNode) {
    completedNode.innerHTML = completed.length ? completed.map(a => `
      <tr>
        <td>${fmtDateOnly(a.date)}</td>
        <td><b>${escapeHtml(a.time || "")}</b></td>
        <td>${escapeHtml(a.clientName || "Cliente")}</td>
        <td>${escapeHtml(a.serviceName || "Servicio")}</td>
        <td>${escapeHtml(a.barberName || "Barbero")}</td>
        <td>${money(a.servicePrice || 0)}</td>
      </tr>
    `).join("") : `<tr><td colspan="6" class="empty">Todavía no hay citas completadas.</td></tr>`;
  }

  document.querySelectorAll("[data-appt][data-status]").forEach(btn =>
    btn.addEventListener("click", () => changeAppointment(btn.dataset.appt, btn.dataset.status))
  );

  document.querySelectorAll("[data-full-assign]").forEach(btn =>
    btn.addEventListener("click", () => {
      const select = document.querySelector(`[data-full-assign-select="${btn.dataset.fullAssign}"]`);
      assignBarberToAppointment(btn.dataset.fullAssign, select?.value || "");
    })
  );
}

async function changeAppointment(id, status) {
  try {
    const appointment = state.appointments.find(a => a.id === id)
      || state.clientAppointments?.find?.(a => a.id === id);
    const bookedSlotId = appointment?.slotId || id;

    const batch = writeBatch(db);

    if (status === "cancelled") {
      batch.delete(doc(db, "appointments", id));
      batch.delete(doc(db, "bookedSlots", bookedSlotId));
      await batch.commit();
      toast("Cita cancelada y eliminada del sistema.");
      return;
    }

    batch.update(doc(db, "appointments", id), { status, updatedAt:serverTimestamp() });
    batch.update(doc(db, "bookedSlots", bookedSlotId), { status, updatedAt:serverTimestamp() });
    await batch.commit();
    toast(`Cita ${statusLabel(status).toLowerCase()}.`);
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo actualizar la cita."));
  }
}


function activeChairOptions(selectedId = "") {
  const chairs = state.chairs.filter(c => c.active !== false);
  if (!chairs.length) return `<option value="">No hay puestos activos</option>`;
  return `<option value="">Selecciona un puesto...</option>` + chairs.map(c =>
    `<option value="${c.id}" ${c.id === selectedId ? "selected" : ""}>${escapeHtml(c.name)}</option>`
  ).join("");
}

function hydrateBarberChairSelectors() {
  const createSelect = $("barberFixedChair");
  if (createSelect) {
    const current = createSelect.value;
    createSelect.innerHTML = activeChairOptions(current);
    if (current && state.chairs.some(c => c.id === current && c.active !== false)) {
      createSelect.value = current;
    }
  }

  const editSelect = $("barberChairEditorSelect");
  if (editSelect && $("barberChairEditorId")?.value) {
    const barber = state.barbers.find(b => b.id === $("barberChairEditorId").value);
    editSelect.innerHTML = activeChairOptions(barber?.chairId || "");
  }
}

function openBarberChairEditor(barberId) {
  const barber = state.barbers.find(b => b.id === barberId);
  if (!barber) return;

  $("barberChairEditorId").value = barber.id;
  $("barberChairEditorName").textContent = barber.name || "Barbero";
  $("barberChairEditorSelect").innerHTML = activeChairOptions(barber.chairId || "");
  if (barber.chairId && state.chairs.some(c => c.id === barber.chairId && c.active !== false)) {
    $("barberChairEditorSelect").value = barber.chairId;
  }
  openModal("barberChairModal");
}

async function saveBarberFixedChair(e) {
  e.preventDefault();

  const barberId = $("barberChairEditorId").value;
  const chairId = $("barberChairEditorSelect").value;
  const chair = state.chairs.find(c => c.id === chairId && c.active !== false);

  if (!barberId || !chair) return toast("Selecciona un puesto activo.");

  const barber = state.barbers.find(b => b.id === barberId);
  if (!barber) return;

  try {
    const batch = writeBatch(db);
    batch.set(doc(db, "users", barberId), {
      chairId:chair.id,
      chairName:chair.name,
      updatedAt:serverTimestamp()
    }, { merge:true });

    batch.set(doc(db, "publicBarbers", barberId), {
      name:barber.name || "Barbero",
      active:barber.active !== false,
      chairId:chair.id,
      chairName:chair.name,
      updatedAt:serverTimestamp()
    }, { merge:true });

    await batch.commit();
    closeModal("barberChairModal");
    toast(`${barber.name} ahora tiene ${chair.name} como puesto fijo.`);
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, `No se pudo asignar el puesto. ${err?.code || ""}`));
  }
}

function renderBarbers() {
  const orderedBarbers = [...state.barbers].sort((a,b) => {
    const aActive = a.active !== false ? 0 : 1;
    const bActive = b.active !== false ? 0 : 1;
    return aActive - bActive || (a.name || "").localeCompare(b.name || "");
  });

  $("barberCards").innerHTML = orderedBarbers.length ? orderedBarbers.map(b => {
    const active = b.active !== false;

    return `<article class="person-card barber-admin-card ${active ? "" : "is-disabled"}">
      <div class="barber-admin-top">
        <div class="barber-admin-avatar">${escapeHtml((b.name || "B").charAt(0).toUpperCase())}</div>
        <span class="barber-state ${active ? "active" : "inactive"}">${active ? "ACTIVO" : "DESHABILITADO"}</span>
      </div>

      <span class="card-kicker">USUARIO BARBERO</span>
      <h3>${escapeHtml(b.name)}</h3>
      <div class="card-meta">${active
        ? `Comisiones configuradas por separado`
        : "Acceso suspendido temporalmente"}</div>

      <div class="barber-commission-pills">
        <div><span>Servicios</span><strong>${Number(b.commission ?? 50)}%</strong></div>
        <div><span>Productos</span><strong>${Number(b.productCommission ?? 0)}%</strong></div>
      </div>

      <div class="barber-fixed-chair-card ${b.chairId ? "assigned" : "unassigned"}">
        <span class="barber-fixed-chair-icon">⌖</span>
        <div>
          <small>PUESTO FIJO</small>
          <strong>${escapeHtml(b.chairName || "Sin asignar")}</strong>
        </div>
      </div>

      <button class="barber-edit-chair-btn"
        data-edit-chair="${b.id}"
        type="button">${b.chairId ? "⌖ Cambiar puesto" : "+ Asignar puesto"}</button>

      <div class="credential">
        <span>Usuario</span>
        <b>${escapeHtml(b.username || "")}</b>
        <small>Conserva su misma contraseña e historial</small>
      </div>

      <button class="barber-edit-commission-btn"
        data-edit-commission="${b.id}"
        type="button">⚙ Editar comisiones</button>

      ${active ? `
        <div class="barber-account-status status-active-box">
          <span>✓</span>
          <div><b>Cuenta habilitada</b><small>Puede ingresar y recibir citas.</small></div>
        </div>
        <button class="barber-toggle-btn disable"
          data-toggle-barber="${b.id}"
          data-next-active="false"
          type="button">
          <span>⊘</span> Deshabilitar usuario
        </button>
      ` : `
        <div class="barber-account-status status-disabled-box">
          <span>!</span>
          <div><b>Cuenta deshabilitada</b><small>No puede ingresar ni aparecer para clientes.</small></div>
        </div>
        <button class="barber-toggle-btn enable"
          data-toggle-barber="${b.id}"
          data-next-active="true"
          type="button">
          <span>✓</span> Habilitar usuario
        </button>
      `}

      <div class="barber-toggle-help">${active
        ? "Puedes deshabilitarlo temporalmente sin eliminar sus datos."
        : "Al habilitarlo recuperará inmediatamente su acceso con el mismo usuario y contraseña."}</div>
    </article>`;
  }).join("") : `<div class="empty">Todavía no has creado barberos.</div>`;

  document.querySelectorAll("[data-toggle-barber]").forEach(btn =>
    btn.addEventListener("click", () =>
      toggleBarberStatus(
        btn.dataset.toggleBarber,
        btn.dataset.nextActive === "true"
      )
    )
  );

  document.querySelectorAll("[data-edit-commission]").forEach(btn =>
    btn.addEventListener("click", () => openCommissionEditor(btn.dataset.editCommission))
  );

  document.querySelectorAll("[data-edit-chair]").forEach(btn =>
    btn.addEventListener("click", () => openBarberChairEditor(btn.dataset.editChair))
  );
}


function openCommissionEditor(barberId) {
  const barber = state.barbers.find(b => b.id === barberId);
  if (!barber) return;

  $("commissionBarberId").value = barber.id;
  $("commissionBarberName").textContent = barber.name || "Barbero";
  $("editServiceCommission").value = Number(barber.commission ?? 50);
  $("editProductCommission").value = Number(barber.productCommission ?? 0);
  openModal("commissionModal");
}

async function saveBarberCommissions(e) {
  e.preventDefault();

  const barberId = $("commissionBarberId").value;
  const serviceCommission = Number($("editServiceCommission").value);
  const productCommission = Number($("editProductCommission").value);

  if (!barberId) return;
  if (serviceCommission < 0 || serviceCommission > 100) {
    return toast("La comisión de servicios debe estar entre 0 y 100%.");
  }
  if (productCommission < 0 || productCommission > 100) {
    return toast("La comisión de productos debe estar entre 0 y 100%.");
  }

  try {
    await updateDoc(doc(db, "users", barberId), {
      commission:serviceCommission,
      productCommission,
      updatedAt:serverTimestamp()
    });
    closeModal("commissionModal");
    toast("Comisiones actualizadas.");
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudieron actualizar las comisiones."));
  }
}

async function createBarber(e) {
  e.preventDefault();

  const name = $("barberName").value.trim();
  const username = $("barberUsername").value.trim().toLowerCase();
  const password = $("barberPassword").value;
  const password2 = $("barberPassword2").value;
  const commission = Number($("barberCommission").value);
  const productCommission = Number($("barberProductCommission").value);
  const chairId = $("barberFixedChair").value;
  const fixedChair = state.chairs.find(c => c.id === chairId && c.active !== false);

  if (!/^[a-z0-9._-]{3,30}$/.test(username)) return toast("El usuario debe tener mínimo 3 caracteres, sin espacios.");
  if (password.length < 6) return toast("La contraseña debe tener mínimo 6 caracteres.");
  if (password !== password2) return toast("Las contraseñas no coinciden.");
  if (commission < 0 || commission > 100) return toast("La comisión de servicios debe estar entre 0 y 100%.");
  if (productCommission < 0 || productCommission > 100) return toast("La comisión de productos debe estar entre 0 y 100%.");
  if (!fixedChair) return toast("Selecciona el puesto fijo del barbero.");

  let secondaryApp = null;
  try {
    secondaryApp = initializeApp(firebaseConfig, `create-user-${Date.now()}`);
    const secondaryAuth = getAuth(secondaryApp);

    const result = await createUserWithEmailAndPassword(
      secondaryAuth,
      usernameToEmail(username),
      password
    );

    const uid = result.user.uid;

    await setDoc(doc(db, "users", uid), {
      role:"barber",
      name,
      username,
      emailAlias:usernameToEmail(username),
      commission,
      productCommission,
      chairId:fixedChair.id,
      chairName:fixedChair.name,
      active:true,
      createdAt:serverTimestamp(),
      createdBy:auth.currentUser.uid
    });

    await setDoc(doc(db, "publicBarbers", uid), {
      name,
      active:true,
      chairId:fixedChair.id,
      chairName:fixedChair.name,
      createdAt:serverTimestamp()
    });

    await signOut(secondaryAuth);
    await deleteApp(secondaryApp);
    secondaryApp = null;

    closeModal("barberModal");
    e.target.reset();
    $("barberCommission").value = 50;
    $("barberProductCommission").value = 0;
    hydrateBarberChairSelectors();
    toast(`Usuario ${username} creado en ${fixedChair.name}.`);
  } catch (err) {
    console.error(err);
    if (secondaryApp) {
      try { await deleteApp(secondaryApp); } catch {}
    }
    toast(firebaseErrorMessage(err, "No se pudo crear el usuario."));
  }
}

async function toggleBarberStatus(uid, nextActive) {
  const barber = state.barbers.find(b => b.id === uid);
  if (!barber) return;

  const action = nextActive ? "habilitar" : "deshabilitar";
  const message = nextActive
    ? `¿Habilitar nuevamente a ${barber.name}? Recuperará su acceso con el mismo usuario y contraseña.`
    : `¿Deshabilitar temporalmente a ${barber.name}? No podrá ingresar ni aparecer disponible para clientes.`;

  if (!confirm(message)) return;

  try {
    const batch = writeBatch(db);

    // Perfil privado del usuario.
    batch.update(doc(db, "users", uid), {
      active:nextActive,
      updatedAt:serverTimestamp()
    });

    // set + merge funciona incluso con barberos creados en versiones anteriores
    // que todavía no tengan documento en publicBarbers.
    batch.set(doc(db, "publicBarbers", uid), {
      name:barber.name || "Barbero",
      active:nextActive,
      updatedAt:serverTimestamp()
    }, { merge:true });

    await batch.commit();

    toast(
      nextActive
        ? `${barber.name} fue habilitado. Ya puede volver a iniciar sesión.`
        : `${barber.name} fue deshabilitado temporalmente.`
    );
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(
      err,
      nextActive
        ? "No se pudo habilitar el usuario."
        : "No se pudo deshabilitar el usuario."
    ));
  }
}

function chairAssignedBarbers(chairId, includeInactive = true) {
  return state.barbers.filter(b => b.chairId === chairId && (includeInactive || b.active !== false));
}

function chairAppointmentDateTime(a) {
  if (!a?.date || !a?.time) return null;
  const rawTime = String(a.time).trim();
  const normalizedTime = /^\d{2}:\d{2}$/.test(rawTime) ? `${rawTime}:00` : rawTime;
  const d = new Date(`${a.date}T${normalizedTime}`);
  return Number.isNaN(d.getTime()) ? null : d;
}

function chairAppointmentDuration(a) {
  const service = state.services.find(s => s.id === a?.serviceId)
    || state.services.find(s => String(s.name || "").toLowerCase() === String(a?.serviceName || "").toLowerCase());
  return Math.max(15, Number(service?.duration || 30));
}

function chairAppointmentData(chair) {
  const assignedIds = new Set(chairAssignedBarbers(chair.id, true).map(b => b.id));
  if (!assignedIds.size) return { current:null, next:null };
  const now = new Date();
  const active = state.appointments
    .filter(a => assignedIds.has(a.barberId) && !["completed","cancelled"].includes(a.status))
    .map(a => ({ a, start:chairAppointmentDateTime(a) }))
    .filter(x => x.start)
    .sort((x,y) => x.start - y.start);

  let current = null;
  for (const x of active) {
    const end = new Date(x.start.getTime() + chairAppointmentDuration(x.a) * 60000);
    if (now >= x.start && now < end) {
      current = x.a;
      break;
    }
  }
  const nextItem = active.find(x => x.start >= now);
  return { current, next:nextItem?.a || current || null };
}

function chairOperationalStatus(chair) {
  if (chair.active === false) return { key:"offline", label:"Fuera de servicio", source:"manual" };
  const appointmentData = chairAppointmentData(chair);
  if (appointmentData.current) return { key:"occupied", label:"Ocupado", source:"appointment", appointment:appointmentData.current };
  if (chair.operationalStatus === "occupied") return { key:"occupied", label:"Ocupado", source:"manual" };
  return { key:"available", label:"Disponible", source:"automatic" };
}

function chairTodaySales(chairId) {
  return state.sales
    .filter(s => s.chairId === chairId && todayIso(s.date))
    .sort((a,b) => jsDate(b.date) - jsDate(a.date));
}

function chairLastActivity(chairId) {
  return [...state.sales]
    .filter(s => s.chairId === chairId)
    .sort((a,b) => jsDate(b.date) - jsDate(a.date))[0] || null;
}

function chairTodayProductUnits(chairId) {
  return chairTodaySales(chairId).reduce((sum,sale) => sum + (Array.isArray(sale.products)
    ? sale.products.reduce((n,p) => n + Math.max(0, Number(p.qty || 0)), 0)
    : 0), 0);
}

function formatChairAppointment(a) {
  if (!a) return { main:"Sin citas próximas", meta:"Agenda libre" };
  const barber = state.barbers.find(b => b.id === a.barberId);
  return {
    main:`${fmtDateOnly(a.date)} · ${a.time}`,
    meta:`${a.serviceName || "Servicio"}${barber ? ` · ${barber.name}` : ""}`
  };
}

function renderChairOpsSummary() {
  const node = $("chairOpsSummary");
  if (!node) return;
  const statuses = state.chairs.map(c => chairOperationalStatus(c));
  const available = statuses.filter(s => s.key === "available").length;
  const occupied = statuses.filter(s => s.key === "occupied").length;
  const offline = statuses.filter(s => s.key === "offline").length;
  const todayTotal = state.sales.filter(s => todayIso(s.date)).reduce((sum,s) => sum + Number(s.total || 0), 0);
  node.innerHTML = `
    <article><span>Puestos</span><strong>${state.chairs.length}</strong><small>Capacidad total</small></article>
    <article class="available"><span>Disponibles</span><strong>${available}</strong><small>Listos para atender</small></article>
    <article class="occupied"><span>Ocupados</span><strong>${occupied}</strong><small>En atención ahora</small></article>
    <article class="offline"><span>Fuera de servicio</span><strong>${offline}</strong><small>No disponibles</small></article>
    <article class="gold"><span>Producción de hoy</span><strong>${money(todayTotal)}</strong><small>Total del local</small></article>`;
}

function renderChairs() {
  renderChairOpsSummary();
  const node = $("chairCards");
  if (!node) return;

  node.innerHTML = state.chairs.length ? state.chairs.map((c,i) => {
    const sales = chairTodaySales(c.id);
    const total = sales.reduce((sum,s) => sum + Number(s.total || 0), 0);
    const assigned = chairAssignedBarbers(c.id, true);
    const primary = assigned[0] || null;
    const status = chairOperationalStatus(c);
    const appt = chairAppointmentData(c).next;
    const next = formatChairAppointment(appt);
    const last = chairLastActivity(c.id);
    const lastLabel = last ? fmtDateTime(last.date) : "Sin actividad";

    return `
    <article class="chair-ops-card status-${status.key}">
      <div class="chair-ops-card-top">
        <div>
          <span class="card-kicker">PUESTO ${String(i+1).padStart(2,"0")}</span>
          <h3>${escapeHtml(c.name)}</h3>
        </div>
        <span class="chair-live-status ${status.key}"><i></i>${status.label}</span>
      </div>

      <div class="chair-ops-barber ${primary ? "" : "empty"}">
        <span class="chair-ops-avatar">${primary ? escapeHtml((primary.name || "B").charAt(0).toUpperCase()) : "—"}</span>
        <div>
          <small>BARBERO FIJO</small>
          <strong>${primary ? escapeHtml(primary.name) : "Sin barbero asignado"}</strong>
          <span>${primary ? (primary.active === false ? "Usuario deshabilitado" : "Cuenta activa") : "Asigna un barbero al puesto"}</span>
        </div>
      </div>

      <div class="chair-ops-kpis">
        <div><span>Producción hoy</span><strong>${money(total)}</strong></div>
        <div><span>Servicios hoy</span><strong>${sales.length}</strong></div>
      </div>

      <div class="chair-ops-detail-line">
        <div><span>PRÓXIMA CITA</span><strong>${escapeHtml(next.main)}</strong><small>${escapeHtml(next.meta)}</small></div>
        <div><span>ÚLTIMA ACTIVIDAD</span><strong>${escapeHtml(lastLabel)}</strong><small>${last ? escapeHtml(last.serviceName || "Servicio") : "Sin cobros registrados"}</small></div>
      </div>

      <div class="chair-ops-card-actions">
        <button class="primary-btn" type="button" data-chair-ops-detail="${c.id}">Ver puesto</button>
        <button class="ghost-btn" type="button" data-chair-assign="${c.id}">${primary ? "Cambiar barbero" : "Asignar barbero"}</button>
        <button class="${c.active === false ? "ghost-btn" : "danger-btn"}" type="button" data-chair-toggle-active="${c.id}">${c.active === false ? "Reactivar" : "Fuera de servicio"}</button>
      </div>
    </article>`;
  }).join("") : `<div class="empty">Todavía no hay puestos configurados.</div>`;

  document.querySelectorAll("[data-chair-ops-detail]").forEach(btn =>
    btn.addEventListener("click", () => openChairOperations(btn.dataset.chairOpsDetail))
  );
  document.querySelectorAll("[data-chair-assign]").forEach(btn =>
    btn.addEventListener("click", () => openChairAssignmentModal(btn.dataset.chairAssign))
  );
  document.querySelectorAll("[data-chair-toggle-active]").forEach(btn =>
    btn.addEventListener("click", () => toggleChairActive(btn.dataset.chairToggleActive))
  );

  if (currentChairOpsId && $("chairOperationsModal")?.classList.contains("show")) {
    populateChairOperationsModal(currentChairOpsId);
  }
}

function openChairOperations(chairId) {
  currentChairOpsId = chairId;
  populateChairOperationsModal(chairId);
  openModal("chairOperationsModal");
}

function populateChairOperationsModal(chairId) {
  const chair = state.chairs.find(c => c.id === chairId);
  if (!chair) return;
  const assigned = chairAssignedBarbers(chairId, true);
  const primary = assigned[0] || null;
  const status = chairOperationalStatus(chair);
  const sales = chairTodaySales(chairId);
  const total = sales.reduce((sum,s) => sum + Number(s.total || 0), 0);
  const barberPay = sales.reduce((sum,s) => sum + Number(s.barberAmount || 0), 0);
  const products = chairTodayProductUnits(chairId);
  const appointmentData = chairAppointmentData(chair);
  const next = formatChairAppointment(appointmentData.next);
  const last = chairLastActivity(chairId);

  $("chairOpsModalTitle").textContent = chair.name;
  $("chairOpsModalSubtitle").textContent = `${new Date().toLocaleDateString("es-PA", {weekday:"long", day:"2-digit", month:"long", year:"numeric"})} · Control operativo`;
  const statusNode = $("chairOpsModalStatus");
  statusNode.className = `chair-live-status ${status.key}`;
  statusNode.innerHTML = `<i></i>${status.label}`;

  $("chairOpsModalSummary").innerHTML = `
    <div><span>Producción hoy</span><strong>${money(total)}</strong></div>
    <div><span>Servicios</span><strong>${sales.length}</strong></div>
    <div><span>Pago barbero</span><strong>${money(barberPay)}</strong></div>
    <div><span>Productos vendidos</span><strong>${products}</strong></div>`;

  $("chairOpsMovementCount").textContent = `${sales.length} servicio${sales.length === 1 ? "" : "s"}`;
  $("chairOpsMovementRows").innerHTML = sales.length ? sales.map(s => `
    <tr><td>${jsDate(s.date).toLocaleTimeString("es-PA", {hour:"2-digit",minute:"2-digit"})}</td><td>${escapeHtml(s.serviceName || "Servicio")}</td><td>${escapeHtml(s.barberName || "—")}</td><td><strong>${money(s.total)}</strong></td></tr>`).join("")
    : `<tr><td colspan="4" class="empty">No hay movimientos registrados hoy.</td></tr>`;

  $("chairOpsAssignedBarber").textContent = primary?.name || "Sin barbero asignado";
  $("chairOpsAssignedBarberState").textContent = primary ? (primary.active === false ? "Usuario deshabilitado" : `Puesto fijo · ${primary.username || "cuenta activa"}`) : "Puedes asignarlo desde esta ventana";
  $("chairOpsNextAppointment").textContent = next.main;
  $("chairOpsNextAppointmentMeta").textContent = next.meta;
  $("chairOpsLastActivity").textContent = last ? fmtDateTime(last.date) : "Sin actividad";

  const assignBtn = $("chairOpsAssignBtn");
  assignBtn.textContent = primary ? "Cambiar barbero" : "Asignar barbero";

  const busyBtn = $("chairOpsBusyBtn");
  if (status.source === "appointment") {
    busyBtn.textContent = "Ocupado por cita";
    busyBtn.disabled = true;
  } else {
    busyBtn.disabled = chair.active === false;
    busyBtn.textContent = chair.operationalStatus === "occupied" ? "Marcar disponible" : "Marcar ocupado";
  }

  const activeBtn = $("chairOpsActiveBtn");
  activeBtn.textContent = chair.active === false ? "Reactivar puesto" : "Fuera de servicio";
  activeBtn.className = chair.active === false ? "ghost-btn chair-ops-offline-btn" : "danger-btn chair-ops-offline-btn";
}

function openChairAssignmentModal(chairId) {
  const chair = state.chairs.find(c => c.id === chairId);
  if (!chair) return;
  const assigned = chairAssignedBarbers(chairId, true)[0] || null;
  $("chairAssignId").value = chairId;
  $("chairAssignTitle").textContent = `Asignar barbero · ${chair.name}`;
  $("chairAssignCopy").textContent = assigned ? `${assigned.name} está asignado actualmente. Puedes cambiarlo o dejar el puesto sin barbero.` : "Selecciona el barbero fijo para este puesto.";
  const options = [`<option value="">Sin barbero asignado</option>`].concat(
    [...state.barbers].sort((a,b)=>(a.name||"").localeCompare(b.name||"")).map(b => {
      const currentChair = b.chairName ? ` · ${b.chairName}` : "";
      const inactive = b.active === false ? " · DESHABILITADO" : "";
      return `<option value="${b.id}" ${assigned?.id === b.id ? "selected" : ""} ${b.active === false && assigned?.id !== b.id ? "disabled" : ""}>${escapeHtml(b.name || "Barbero")}${escapeHtml(currentChair)}${inactive}</option>`;
    })
  ).join("");
  $("chairAssignBarberSelect").innerHTML = options;
  openModal("chairAssignModal");
}

async function saveChairAssignment(e) {
  e.preventDefault();
  const chairId = $("chairAssignId").value;
  const barberId = $("chairAssignBarberSelect").value;
  const chair = state.chairs.find(c => c.id === chairId);
  if (!chair) return toast("No se encontró el puesto.");
  const selected = barberId ? state.barbers.find(b => b.id === barberId) : null;
  if (barberId && (!selected || selected.active === false)) return toast("Selecciona un barbero activo.");

  try {
    const batch = writeBatch(db);
    const currentAssigned = chairAssignedBarbers(chairId, true);
    currentAssigned.filter(b => b.id !== barberId).forEach(b => {
      batch.set(doc(db, "users", b.id), { chairId:"", chairName:"", updatedAt:serverTimestamp() }, { merge:true });
      batch.set(doc(db, "publicBarbers", b.id), { chairId:"", chairName:"", active:b.active !== false, updatedAt:serverTimestamp() }, { merge:true });
    });

    if (selected) {
      batch.set(doc(db, "users", selected.id), { chairId:chair.id, chairName:chair.name, updatedAt:serverTimestamp() }, { merge:true });
      batch.set(doc(db, "publicBarbers", selected.id), {
        name:selected.name || "Barbero",
        chairId:chair.id,
        chairName:chair.name,
        active:selected.active !== false && chair.active !== false,
        updatedAt:serverTimestamp()
      }, { merge:true });
    }

    await batch.commit();
    closeModal("chairAssignModal");
    toast(selected ? `${selected.name} fue asignado a ${chair.name}.` : `${chair.name} quedó sin barbero asignado.`);
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo guardar la asignación del puesto."));
  }
}

async function toggleChairOccupied(chairId) {
  const chair = state.chairs.find(c => c.id === chairId);
  if (!chair || chair.active === false) return;
  const status = chairOperationalStatus(chair);
  if (status.source === "appointment") return toast("El puesto está ocupado automáticamente por una cita en curso.");
  const occupied = chair.operationalStatus !== "occupied";
  try {
    await setDoc(doc(db, "chairs", chairId), {
      operationalStatus:occupied ? "occupied" : "available",
      updatedAt:serverTimestamp()
    }, { merge:true });
    toast(occupied ? `${chair.name} marcado como ocupado.` : `${chair.name} marcado como disponible.`);
  } catch (err) {
    console.error(err);
    if (err?.code === "permission-denied") {
      toast("No tienes permiso todavía. Debes actualizar las reglas de Firestore para permitir que el barbero cambie el estado de su puesto.");
    } else {
      toast(firebaseErrorMessage(err, "No se pudo cambiar el estado del puesto."));
    }
  }
}

async function toggleChairActive(chairId) {
  const chair = state.chairs.find(c => c.id === chairId);
  if (!chair) return;
  const nextActive = chair.active === false;
  try {
    const batch = writeBatch(db);
    batch.set(doc(db, "chairs", chairId), {
      active:nextActive,
      operationalStatus:"available",
      updatedAt:serverTimestamp()
    }, { merge:true });

    chairAssignedBarbers(chairId, true).forEach(b => {
      batch.set(doc(db, "publicBarbers", b.id), {
        active:nextActive && b.active !== false,
        updatedAt:serverTimestamp()
      }, { merge:true });
    });

    await batch.commit();
    toast(nextActive ? `${chair.name} fue reactivado.` : `${chair.name} quedó fuera de servicio.`);
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo cambiar la disponibilidad del puesto."));
  }
}

async function createChair() {
  try {
    const next = state.chairs.length + 1;
    await setDoc(doc(collection(db, "chairs")), {
      name:`Puesto ${next}`, active:true, order:next, createdAt:serverTimestamp()
    });
    toast(`Puesto ${next} agregado.`);
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo agregar el puesto."));
  }
}

function renderServices() {
  $("serviceCards").innerHTML = state.services.length ? state.services.map(s => `
    <article class="catalog-compact-card service-compact-card">
      <div class="catalog-compact-head">
        <span class="card-kicker">SERVICIO</span>
        <strong class="catalog-price">${money(s.price)}</strong>
      </div>
      <h3>${escapeHtml(s.name)}</h3>
      <small>${Number(s.duration||30)} min aprox.</small>
    </article>
  `).join("") : `<div class="empty">Todavía no has agregado servicios.</div>`;
}

async function createService(e) {
  e.preventDefault();
  try {
    await setDoc(doc(collection(db, "services")), {
      name:$("serviceName").value.trim(),
      price:Number($("servicePrice").value),
      duration:Number($("serviceDuration").value),
      active:true,
      order:state.services.length+1,
      createdAt:serverTimestamp()
    });
    closeModal("serviceModal");
    e.target.reset();
    toast("Servicio agregado.");
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo crear el servicio."));
  }
}

function openProductSalesTodayModal() {
  renderProductSalesToday();
  openModal("productSalesTodayModal");
}

function renderProductSalesToday() {
  if (currentRole !== "admin") return;

  const todaySales = state.sales
    .filter(s => todayIso(s.date) && Array.isArray(s.products) && s.products.length)
    .sort((a,b) => jsDate(b.date) - jsDate(a.date));

  const lines = [];
  todaySales.forEach(sale => {
    sale.products.forEach(item => {
      const qty = Math.max(0, Number(item.qty || 0));
      if (!qty) return;
      const unitPrice = Number(item.unitPrice ?? item.price ?? 0);
      const subtotal = Number(item.subtotal ?? (unitPrice * qty));
      lines.push({
        saleId:sale.id,
        date:sale.date,
        name:item.name || "Producto",
        productId:item.productId || "",
        qty,
        unitPrice,
        subtotal,
        barberName:sale.barberName || "—"
      });
    });
  });

  const total = lines.reduce((sum,x)=>sum+Number(x.subtotal||0),0);
  const units = lines.reduce((sum,x)=>sum+Number(x.qty||0),0);
  const distinct = new Set(lines.map(x => x.productId || x.name)).size;

  $("productSalesTodayDate").textContent = new Date().toLocaleDateString("es-PA", {
    weekday:"long", day:"2-digit", month:"long", year:"numeric"
  });
  $("productSalesTodayTotal").textContent = money(total);
  $("productSalesTodayUnits").textContent = units;
  $("productSalesTodayDistinct").textContent = distinct;
  $("productSalesTodayTickets").textContent = todaySales.length;

  $("productSalesTodayRows").innerHTML = lines.length ? lines.map(line => `
    <tr>
      <td><strong>${jsDate(line.date).toLocaleTimeString("es-PA",{hour:"2-digit",minute:"2-digit"})}</strong></td>
      <td><span class="product-day-name">${escapeHtml(line.name)}</span></td>
      <td>${escapeHtml(line.barberName)}</td>
      <td><span class="product-day-qty">${line.qty}</span></td>
      <td>${money(line.unitPrice)}</td>
      <td class="product-day-subtotal"><strong>${money(line.subtotal)}</strong></td>
    </tr>
  `).join("") : `
    <tr><td colspan="6">
      <div class="product-day-empty">
        <span>▦</span>
        <strong>No se han vendido productos hoy</strong>
        <small>Cuando se confirme un cobro con productos aparecerá aquí.</small>
      </div>
    </td></tr>`;
}


function printInventoryReport() {
  if (currentRole !== "admin") return toast("Solo el administrador puede imprimir el inventario.");
  const products = [...state.products].sort((a,b) => String(a.name||"").localeCompare(String(b.name||""), "es", {sensitivity:"base"}));
  if (!products.length) return toast("No hay productos en el inventario.");

  const totalUnits = products.reduce((sum,p) => sum + Math.max(0, Number(p.stock || 0)), 0);
  const totalValue = products.reduce((sum,p) => sum + (Math.max(0, Number(p.stock || 0)) * Number(p.price || 0)), 0);
  const activeCount = products.filter(p => p.active !== false).length;
  const generatedAt = new Date().toLocaleString("es-PA", { dateStyle:"long", timeStyle:"short" });
  const rows = products.map((p, index) => {
    const stock = Math.max(0, Number(p.stock || 0));
    const price = Number(p.price || 0);
    const subtotal = +(stock * price).toFixed(2);
    const status = p.active !== false ? "Activo" : "Deshabilitado";
    return `
      <tr>
        <td>${index + 1}</td>
        <td>${receiptSafeText(normalizeBarcode(p.barcode) || "Sin código")}</td>
        <td>${receiptSafeText(p.name || "Producto")}</td>
        <td class="num">${receiptSafeText(money(price))}</td>
        <td class="num">${stock}</td>
        <td>${status}</td>
        <td class="num">${receiptSafeText(money(subtotal))}</td>
      </tr>`;
  }).join("");

  const printWindow = window.open("", "_blank", "width=1200,height=900");
  if (!printWindow) return toast("Tu navegador bloqueó la ventana de impresión.");

  printWindow.document.write(`<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Inventario - Barbería Los Mágicos</title>
<style>
  :root{color-scheme:light;}
  *{box-sizing:border-box} body{margin:0;background:#fff;color:#222;font-family:Arial,Helvetica,sans-serif} 
  .page{padding:20px 22px 28px;max-width:1100px;margin:0 auto} 
  .topnote{display:flex;justify-content:space-between;gap:12px;font-size:11px;color:#666;margin-bottom:10px} 
  .head{display:flex;justify-content:space-between;gap:18px;align-items:flex-start;padding-bottom:14px;border-bottom:2px solid #c8a35a} 
  .brand{display:flex;gap:14px;align-items:center} .logo{width:48px;height:48px;border-radius:12px;display:grid;place-items:center;background:#e8d7ac;color:#4e3708;font-weight:800;font-size:20px} 
  h1{margin:0;font-size:24px} .sub{margin:3px 0 0;color:#7a6b50;font-size:12px;text-transform:uppercase;letter-spacing:.7px} 
  .doc{text-align:right} .doc h2{margin:0;font-size:18px} .doc p{margin:4px 0 0;color:#666;font-size:11px} 
  .kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0} .kpi{border:1px solid #ddd3c2;border-radius:10px;padding:12px} .kpi.highlight{background:#f5e8c8;border-color:#d5b06d} .kpi span{display:block;color:#7a6b50;font-size:10px;text-transform:uppercase;letter-spacing:.7px} .kpi strong{display:block;margin-top:5px;font-size:22px;color:#1d1d1d} .kpi small{display:block;margin-top:4px;color:#666;font-size:10px} 
  .section-title{margin:12px 0 8px;font-size:13px;font-weight:800;color:#7a5b1f;text-transform:uppercase;letter-spacing:.7px} 
  table{width:100%;border-collapse:collapse;font-size:11px} th{background:#202020;color:#fff;text-align:left;padding:9px 8px;font-size:10px;text-transform:uppercase;letter-spacing:.5px} td{padding:8px;border-bottom:1px solid #e9e4da} .num{text-align:right;white-space:nowrap} 
  .foot{margin-top:26px;padding-top:10px;border-top:1px solid #ddd;color:#666;font-size:10px;text-align:center} 
  .print-note{margin:0 0 10px;text-align:center;color:#666;font-size:10px} 
  @media print{body{background:#fff}.page{padding:0}.print-note{display:none}@page{size:A4;margin:10mm}}
</style>
</head>
<body>
<div class="print-note">En la ventana de impresión puedes elegir <b>Guardar como PDF</b>.</div>
<main class="page">
  <div class="topnote"><span>${receiptSafeText(new Date().toLocaleString("es-PA"))}</span><span>Barbería Los Mágicos</span></div>
  <header class="head">
    <div class="brand">
      <div class="logo">LM</div>
      <div>
        <h1>Barbería Los Mágicos</h1>
        <p class="sub">Inventario general de productos</p>
      </div>
    </div>
    <div class="doc">
      <h2>Reporte de inventario</h2>
      <p>Generado: ${receiptSafeText(generatedAt)}</p>
    </div>
  </header>

  <section class="kpis">
    <div class="kpi"><span>Productos registrados</span><strong>${products.length}</strong><small>Total en catálogo</small></div>
    <div class="kpi"><span>Productos activos</span><strong>${activeCount}</strong><small>Disponibles para venta</small></div>
    <div class="kpi"><span>Unidades en inventario</span><strong>${totalUnits}</strong><small>Suma de existencias</small></div>
    <div class="kpi highlight"><span>Valor estimado</span><strong>${receiptSafeText(money(totalValue))}</strong><small>Precio x existencia</small></div>
  </section>

  <h3 class="section-title">Detalle de inventario</h3>
  <table>
    <thead><tr><th>#</th><th>Código</th><th>Producto</th><th>Precio</th><th>Existencia</th><th>Estado</th><th>Valor en stock</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>

  <footer class="foot">Barbería Los Mágicos · Inventario generado por el sistema de gestión</footer>
</main>
<script>window.addEventListener("load",()=>setTimeout(()=>window.print(),250));</script>
</body>
</html>`);
  printWindow.document.close();
}

function normalizeProductName(value) {
  return String(value || "")
    .trim()
    .toLocaleLowerCase("es")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ");
}

function normalizeBarcode(value) {
  return String(value ?? "")
    .trim()
    .replace(/\s+/g, "")
    .toUpperCase();
}

function findProductByBarcode(value, excludeId = "") {
  const barcode = normalizeBarcode(value);
  if (!barcode) return null;
  return state.products.find(p => p.id !== excludeId && normalizeBarcode(p.barcode) === barcode) || null;
}

function findProductByName(value, excludeId = "") {
  const name = normalizeProductName(value);
  if (!name) return null;
  return state.products.find(p => p.id !== excludeId && normalizeProductName(p.name) === name) || null;
}

function openNewProductModal() {
  const form = $("productForm");
  form?.reset();
  if ($("productEditId")) $("productEditId").value = "";
  if ($("productStock")) $("productStock").value = "0";
  if ($("productModalEyebrow")) $("productModalEyebrow").textContent = "NUEVO PRODUCTO";
  if ($("productModalTitle")) $("productModalTitle").textContent = "Agregar producto";
  if ($("productSaveBtn")) $("productSaveBtn").textContent = "Guardar producto";
  openModal("productModal");
  requestAnimationFrame(() => $("productBarcode")?.focus());
}

function openEditProductModal(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  if ($("productEditId")) $("productEditId").value = product.id;
  if ($("productBarcode")) $("productBarcode").value = product.barcode || "";
  if ($("productName")) $("productName").value = product.name || "";
  if ($("productPrice")) $("productPrice").value = Number(product.price || 0).toFixed(2);
  if ($("productStock")) $("productStock").value = Math.max(0, Number(product.stock || 0));
  if ($("productModalEyebrow")) $("productModalEyebrow").textContent = "EDITAR PRODUCTO";
  if ($("productModalTitle")) $("productModalTitle").textContent = product.name || "Producto";
  if ($("productSaveBtn")) $("productSaveBtn").textContent = "Guardar cambios";
  openModal("productModal");
  requestAnimationFrame(() => $("productBarcode")?.focus());
}

function newBulkProductRow(data = {}) {
  return {
    key:`bulk-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
    barcode:String(data.barcode || ""),
    name:String(data.name || ""),
    price:data.price ?? "",
    stock:data.stock ?? "",
    active:data.active !== false
  };
}

function openBulkProductsModal() {
  if (!bulkProductRows.length) {
    bulkProductRows = Array.from({length:6}, () => newBulkProductRow());
  }
  renderBulkProductRows();
  $("bulkPastePanel")?.classList.add("hidden");
  if ($("bulkPasteText")) $("bulkPasteText").value = "";
  openModal("bulkProductsModal");
}

function resetBulkProductRows() {
  bulkProductRows = Array.from({length:6}, () => newBulkProductRow());
  renderBulkProductRows();
}

function addBulkProductRow(data = {}) {
  bulkProductRows.push(newBulkProductRow(data));
  renderBulkProductRows();
  requestAnimationFrame(() => {
    const rows = document.querySelectorAll("#bulkProductsRows tr");
    rows[rows.length-1]?.querySelector('[data-bulk-field="barcode"]')?.focus();
  });
}

function removeBulkProductRow(key) {
  bulkProductRows = bulkProductRows.filter(row => row.key !== key);
  if (!bulkProductRows.length) bulkProductRows.push(newBulkProductRow());
  renderBulkProductRows();
}

function bulkExistingProduct(row) {
  const barcode = normalizeBarcode(row.barcode);
  if (barcode) {
    const byBarcode = findProductByBarcode(barcode);
    if (byBarcode) return byBarcode;
  }
  return findProductByName(row.name) || null;
}

function syncBulkProductRowFromInput(input) {
  const key = input.dataset.bulkKey;
  const field = input.dataset.bulkField;
  const row = bulkProductRows.find(r => r.key === key);
  if (!row || !field) return;

  if (field === "active") row.active = input.value === "true";
  else row[field] = input.value;

  renderBulkProductRowStatus(key);
  updateBulkProductsSummary();
}

function bulkRowAssessment(row) {
  const barcode = normalizeBarcode(row.barcode);
  const name = String(row.name || "").trim();
  const price = Number(row.price);
  const stockNumber = Number(row.stock);
  const stock = Math.floor(stockNumber);
  const allBlank = !barcode && !name && String(row.price||"").trim()==="" && String(row.stock||"").trim()==="";
  if (allBlank) return { empty:true, valid:false };
  if (!name) return { valid:false, message:"Falta producto" };
  if (!Number.isFinite(price) || price <= 0) return { valid:false, message:"Precio inválido" };
  if (!Number.isFinite(stockNumber) || stockNumber < 0 || stockNumber !== stock) return { valid:false, message:"Cantidad inválida" };

  const existing = bulkExistingProduct(row);
  if (!barcode && !existing) return { valid:false, message:"Código requerido" };

  if (barcode) {
    const conflict = findProductByBarcode(barcode, existing?.id || "");
    if (conflict) return { valid:false, message:`Código usado por ${conflict.name}` };
  }

  return {
    valid:true,
    barcode:barcode || normalizeBarcode(existing?.barcode),
    name,
    price:+price.toFixed(2),
    stock,
    existing
  };
}

function renderBulkProductRowStatus(key) {
  const row = bulkProductRows.find(r => r.key === key);
  const badge = document.querySelector(`[data-bulk-status="${key}"]`);
  if (!row || !badge) return;
  const check = bulkRowAssessment(row);
  badge.className = "bulk-row-status";
  if (check.empty) {
    badge.textContent = "VACÍA";
    badge.classList.add("empty");
  } else if (!check.valid) {
    badge.textContent = check.message?.toUpperCase().includes("CÓDIGO") ? "REVISAR CÓDIGO" : "REVISAR";
    badge.title = check.message || "Revisar fila";
    badge.classList.add("invalid");
  } else if (check.existing) {
    badge.textContent = "ACTUALIZAR";
    badge.classList.add("update");
  } else {
    badge.textContent = "NUEVO";
    badge.classList.add("new");
  }
}

function updateBulkProductsSummary() {
  const valid = bulkProductRows.filter(row => bulkRowAssessment(row).valid).length;
  if ($("bulkProductsValidCount")) $("bulkProductsValidCount").textContent = valid;
}

function renderBulkProductRows() {
  const tbody = $("bulkProductsRows");
  if (!tbody) return;

  tbody.innerHTML = bulkProductRows.map((row,index) => `
    <tr data-bulk-row="${row.key}">
      <td class="bulk-row-number">${String(index+1).padStart(2,"0")}</td>
      <td><input class="bulk-cell bulk-barcode-cell" data-bulk-key="${row.key}" data-bulk-field="barcode" value="${escapeHtml(row.barcode)}" placeholder="Código"></td>
      <td><input class="bulk-cell bulk-name-cell" data-bulk-key="${row.key}" data-bulk-field="name" value="${escapeHtml(row.name)}" placeholder="Producto"></td>
      <td><input class="bulk-cell" data-bulk-key="${row.key}" data-bulk-field="price" type="number" min="0.01" step="0.01" value="${escapeHtml(row.price)}" placeholder="0.00"></td>
      <td><input class="bulk-cell" data-bulk-key="${row.key}" data-bulk-field="stock" type="number" min="0" step="1" value="${escapeHtml(row.stock)}" placeholder="0"></td>
      <td>
        <select class="bulk-cell bulk-status-select" data-bulk-key="${row.key}" data-bulk-field="active">
          <option value="true" ${row.active ? "selected" : ""}>Activo</option>
          <option value="false" ${!row.active ? "selected" : ""}>Inactivo</option>
        </select>
      </td>
      <td><span class="bulk-row-status" data-bulk-status="${row.key}">VACÍA</span></td>
      <td><button class="bulk-row-delete" data-bulk-delete="${row.key}" type="button" aria-label="Eliminar fila">×</button></td>
    </tr>
  `).join("");

  tbody.querySelectorAll("[data-bulk-field]").forEach(input => {
    input.addEventListener("input", () => syncBulkProductRowFromInput(input));
    input.addEventListener("change", () => syncBulkProductRowFromInput(input));
  });
  tbody.querySelectorAll("[data-bulk-delete]").forEach(btn =>
    btn.addEventListener("click", () => removeBulkProductRow(btn.dataset.bulkDelete))
  );

  bulkProductRows.forEach(row => renderBulkProductRowStatus(row.key));
  updateBulkProductsSummary();
}

function parseBulkPastedProducts(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean)
    .map(line => {
      const cols = line.includes("\t") ? line.split("\t") : line.split(/[;,]/);
      return {
        barcode:String(cols[0] || "").trim(),
        name:String(cols[1] || "").trim(),
        price:String(cols[2] || "").trim().replace(/^\$/,""),
        stock:String(cols[3] || "").trim(),
        active:!String(cols[4] || "").toLowerCase().includes("inactiv")
      };
    });
}

function importBulkPasteText() {
  const pasted = parseBulkPastedProducts($("bulkPasteText")?.value || "");
  if (!pasted.length) return toast("Pega al menos una fila con Código, Producto, Precio y Cantidad.");

  const firstLooksLikeHeader = /codigo|código|barcode/i.test(pasted[0].barcode) || /producto|nombre/i.test(pasted[0].name);
  const rows = firstLooksLikeHeader ? pasted.slice(1) : pasted;
  if (!rows.length) return toast("No se encontraron productos para importar.");

  const existingFilled = bulkProductRows.filter(row => !bulkRowAssessment(row).empty);
  bulkProductRows = [
    ...existingFilled,
    ...rows.map(row => newBulkProductRow(row))
  ];
  renderBulkProductRows();
  $("bulkPastePanel")?.classList.add("hidden");
  if ($("bulkPasteText")) $("bulkPasteText").value = "";
  toast(`${rows.length} fila${rows.length===1?"":"s"} agregada${rows.length===1?"":"s"} a la tabla.`);
}

async function saveBulkProducts() {
  const filled = bulkProductRows.filter(row => !bulkRowAssessment(row).empty);
  if (!filled.length) return toast("Agrega al menos un producto.");

  const assessments = filled.map(row => ({ row, check:bulkRowAssessment(row) }));
  const invalid = assessments.find(item => !item.check.valid);
  if (invalid) return toast(`Revisa ${invalid.row.name || "la fila"}: ${invalid.check.message}.`);

  const names = new Set();
  const barcodes = new Set();
  for (const {row,check} of assessments) {
    const nameKey = normalizeProductName(check.name);
    if (names.has(nameKey)) return toast(`El producto “${row.name}” está repetido en la carga.`);
    names.add(nameKey);
    const barcodeKey = normalizeBarcode(check.barcode);
    if (barcodeKey) {
      if (barcodes.has(barcodeKey)) return toast(`El código “${barcodeKey}” está repetido en la carga.`);
      barcodes.add(barcodeKey);
    }
  }

  const saveBtn = $("bulkProductsSaveBtn");
  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.textContent = "Guardando…";
  }

  let created = 0;
  let updated = 0;
  try {
    const operations = assessments.map(({row,check}, index) => {
      const existing = check.existing;
      const data = {
        barcode:normalizeBarcode(check.barcode),
        name:check.name,
        price:check.price,
        stock:check.stock,
        active:row.active !== false,
        updatedAt:serverTimestamp()
      };
      if (existing) {
        updated += 1;
        return { ref:doc(db,"products",existing.id), data, isNew:false };
      }
      created += 1;
      return {
        ref:doc(collection(db,"products")),
        data:{...data, order:state.products.length + index + 1, createdAt:serverTimestamp()},
        isNew:true
      };
    });

    for (let start=0; start<operations.length; start+=400) {
      const batch = writeBatch(db);
      operations.slice(start,start+400).forEach(op => batch.set(op.ref, op.data, { merge:!op.isNew }));
      await batch.commit();
    }

    closeModal("bulkProductsModal");
    bulkProductRows = [];
    toast(`Inventario actualizado: ${created} nuevo${created===1?"":"s"} · ${updated} actualizado${updated===1?"":"s"}.`);
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo cargar el inventario."));
  } finally {
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.textContent = "Cargar inventario →";
    }
  }
}

function renderProducts() {
  if (currentRole !== "admin") return;
  const tbody = $("productCards");
  if (!tbody) return;

  const allProducts = [...state.products].sort((a,b) => String(a.name||"").localeCompare(String(b.name||""), "es", {sensitivity:"base"}));
  const queryValue = String(productSearchQuery || $("productSearchInput")?.value || "").trim();
  const normalizedNameQuery = normalizeProductName(queryValue);
  const normalizedBarcodeQuery = normalizeBarcode(queryValue);
  const filtered = queryValue ? allProducts.filter(p =>
    normalizeProductName(p.name).includes(normalizedNameQuery) ||
    (normalizedBarcodeQuery && normalizeBarcode(p.barcode).includes(normalizedBarcodeQuery))
  ) : allProducts;

  const totalUnits = allProducts.reduce((sum,p) => sum + Math.max(0, Number(p.stock || 0)), 0);
  const noBarcode = allProducts.filter(p => !normalizeBarcode(p.barcode)).length;
  if ($("productListCount")) $("productListCount").textContent = allProducts.length;
  if ($("productUnitCount")) $("productUnitCount").textContent = totalUnits;
  if ($("productNoBarcodeCount")) $("productNoBarcodeCount").textContent = noBarcode;

  tbody.innerHTML = filtered.length ? filtered.map(p => {
    const active = p.active !== false;
    const stock = Math.max(0, Number(p.stock || 0));
    const barcode = normalizeBarcode(p.barcode);
    return `<tr class="product-detail-row ${active ? "" : "product-disabled"}" data-product-row="${p.id}">
      <td data-label="Código"><span class="product-barcode ${barcode ? "" : "missing"}">${escapeHtml(barcode || "SIN CÓDIGO")}</span></td>
      <td data-label="Producto"><strong class="product-list-name">${escapeHtml(p.name)}</strong>${stock <= 2 ? `<small class="product-low-stock">Stock bajo</small>` : ""}</td>
      <td data-label="Precio"><strong class="product-list-price">${money(p.price)}</strong></td>
      <td data-label="Existencia"><span class="product-list-stock ${stock <= 2 ? "low" : ""}">${stock}</span></td>
      <td data-label="Estado"><span class="product-status ${active ? "active" : "inactive"}">${active ? "ACTIVO" : "DESHABILITADO"}</span></td>
      <td data-label="Acciones">
        <div class="product-list-actions">
          <button class="product-edit-btn" data-edit-product="${p.id}" type="button">Editar</button>
          <button class="stock-adjust-btn" data-stock-product="${p.id}" type="button">Stock</button>
          <button class="product-toggle-btn ${active ? "disable" : "enable"}" data-toggle-product="${p.id}" data-product-active="${active ? "false" : "true"}" type="button">${active ? "Deshabilitar" : "Habilitar"}</button>
        </div>
      </td>
    </tr>`;
  }).join("") : `<tr><td colspan="6"><div class="empty">${queryValue ? "No hay productos que coincidan con la búsqueda o código." : "Todavía no has agregado productos al inventario."}</div></td></tr>`;

  document.querySelectorAll("[data-edit-product]").forEach(btn =>
    btn.addEventListener("click", () => openEditProductModal(btn.dataset.editProduct))
  );
  document.querySelectorAll("[data-toggle-product]").forEach(btn =>
    btn.addEventListener("click", () =>
      toggleProductStatus(btn.dataset.toggleProduct, btn.dataset.productActive === "true")
    )
  );
  document.querySelectorAll("[data-stock-product]").forEach(btn =>
    btn.addEventListener("click", () => openProductStockEditor(btn.dataset.stockProduct))
  );
}

async function createProduct(e) {
  e.preventDefault();
  try {
    const editId = $("productEditId")?.value || "";
    const barcode = normalizeBarcode($("productBarcode").value);
    const name = $("productName").value.trim();
    const price = Number($("productPrice").value);
    const stock = Math.max(0, Math.floor(Number($("productStock").value || 0)));

    if (!barcode) return toast("Escanea o escribe el código de barras.");
    if (!name || !price || price <= 0) return toast("Revisa nombre y precio del producto.");

    const barcodeConflict = findProductByBarcode(barcode, editId);
    if (barcodeConflict) return toast(`Ese código ya pertenece a “${barcodeConflict.name}”.`);
    const nameConflict = findProductByName(name, editId);
    if (nameConflict) return toast(`Ya existe un producto llamado “${nameConflict.name}”.`);

    const data = {
      barcode,
      name,
      price:+price.toFixed(2),
      stock,
      updatedAt:serverTimestamp()
    };

    if (editId) {
      await updateDoc(doc(db, "products", editId), data);
      toast("Producto actualizado.");
    } else {
      await setDoc(doc(collection(db, "products")), {
        ...data,
        active:true,
        order:state.products.length+1,
        createdAt:serverTimestamp()
      });
      toast("Producto agregado al inventario.");
    }

    closeModal("productModal");
    e.target.reset();
    if ($("productEditId")) $("productEditId").value = "";
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo guardar el producto."));
  }
}

function openProductStockEditor(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  $("productStockId").value = product.id;
  $("productStockName").textContent = product.name || "Producto";
  $("productStockQty").value = Math.max(0, Number(product.stock || 0));
  openModal("productStockModal");
}

async function saveProductStock(e) {
  e.preventDefault();
  const productId = $("productStockId").value;
  const stock = Math.max(0, Math.floor(Number($("productStockQty").value || 0)));
  if (!productId) return;
  try {
    await updateDoc(doc(db, "products", productId), { stock, updatedAt:serverTimestamp() });
    closeModal("productStockModal");
    toast("Existencia actualizada.");
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo actualizar el inventario."));
  }
}

async function toggleProductStatus(productId, nextActive) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;
  if (!confirm(`${nextActive ? "Habilitar" : "Deshabilitar"} ${product.name}?`)) return;

  try {
    await updateDoc(doc(db, "products", productId), {
      active:nextActive,
      updatedAt:serverTimestamp()
    });
    toast(nextActive ? "Producto habilitado." : "Producto deshabilitado.");
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo actualizar el producto."));
  }
}


function renderReports() {
  if (currentRole !== "admin") return;

  const period = dashboardPeriod();
  const monthSales = state.sales.filter(s => saleInDashboardPeriod(s, period));

  const total = monthSales.reduce((a,s) => a + Number(s.total || 0), 0);
  const barberTotal = monthSales.reduce((a,s) => a + Number(s.barberAmount || 0), 0);
  const shopTotal = monthSales.reduce((a,s) => a + Number(s.shopAmount || 0), 0);

  $("reportTotal").textContent = money(total);
  $("reportBarbers").textContent = money(barberTotal);
  $("reportShop").textContent = money(shopTotal);
  $("reportTotalMeta").textContent = `${monthSales.length} servicio${monthSales.length === 1 ? "" : "s"} en el período`;
  $("reportPeriodTitle").textContent = `Reporte · ${period.label}`;
  $("reportGeneratedAt").textContent = `Generado el ${new Date().toLocaleString("es-PA", {dateStyle:"long", timeStyle:"short"})}`;

  const chairRows = state.chairs.map(chair => {
    const sales = monthSales.filter(s => s.chairId === chair.id);
    return {
      chair,
      count: sales.length,
      gross: sales.reduce((a,s)=>a+Number(s.total||0),0),
      barber: sales.reduce((a,s)=>a+Number(s.barberAmount||0),0),
      shop: sales.reduce((a,s)=>a+Number(s.shopAmount||0),0)
    };
  }).sort((a,b) => b.gross - a.gross);

  $("reportByChair").innerHTML = chairRows.length ? chairRows.map((r,index) => {
    const avg = r.count ? r.gross / r.count : 0;
    const assigned = state.barbers.filter(b => b.chairId === r.chair.id && b.active !== false);
    const barberNames = assigned.length ? assigned.map(b => escapeHtml(b.name)).join(", ") : "Sin asignar";
    return `
      <tr>
        <td><b>${escapeHtml(r.chair.name)}</b></td>
        <td>${barberNames}</td>
        <td>${r.count}</td>
        <td><b>${money(r.gross)}</b></td>
        <td>${money(r.barber)}</td>
        <td>${money(r.shop)}</td>
        <td>${money(avg)}</td>
      </tr>`;
  }).join("") : `<tr><td colspan="7" class="empty">No hay puestos registrados.</td></tr>`;

  const barberMonthly = state.barbers.map(barber => {
    const sales = monthSales.filter(s => s.barberId === barber.id);
    return {
      barber,
      count: sales.length,
      gross: sales.reduce((a,s)=>a+Number(s.total||0),0),
      pay: sales.reduce((a,s)=>a+Number(s.barberAmount||0),0),
      shop: sales.reduce((a,s)=>a+Number(s.shopAmount||0),0)
    };
  }).sort((a,b) => b.gross - a.gross);

  if ($("reportBarberMonthly")) $("reportBarberMonthly").innerHTML = barberMonthly.length ? barberMonthly.map((r,index) => `
    <article class="report-barber-card premium-card">
      <div class="report-card-top">
        <span class="report-rank">#${String(index+1).padStart(2,"0")}</span>
        <span class="report-pill">Comisión ${Number(r.barber.commission ?? 50)}%</span>
      </div>
      <div class="report-barber-head">
        <div class="report-avatar">${escapeHtml((r.barber.name || "B").charAt(0).toUpperCase())}</div>
        <div><span class="report-card-kicker">BARBERO</span><h4>${escapeHtml(r.barber.name)}</h4><div class="report-card-meta">Resumen del período seleccionado</div></div>
      </div>
      <div class="report-barber-main">
        <div><span>Venta generada</span><strong>${money(r.gross)}</strong></div>
        <div class="gold-number"><span>Saldo del barbero</span><strong>${money(r.pay)}</strong></div>
      </div>
      <div class="report-split report-split-3">
        <div><span>Servicios</span><b>${r.count}</b></div>
        <div><span>Ingreso barbería</span><b>${money(r.shop)}</b></div>
        <div><span>Promedio por servicio</span><b>${money(r.count ? r.gross / r.count : 0)}</b></div>
      </div>
    </article>
  `).join("") : `<div class="empty">No hay barberos registrados.</div>`;

  $("reportMonthlyBarbersTable").innerHTML = barberMonthly.length ? barberMonthly.map(r => `
    <tr>
      <td><b>${escapeHtml(r.barber.name)}</b></td>
      <td>${r.count}</td>
      <td><b>${money(r.gross)}</b></td>
      <td>${Number(r.barber.commission ?? 50)}%</td>
      <td class="money-positive">${money(r.pay)}</td>
      <td>${money(r.shop)}</td>
    </tr>
  `).join("") : `<tr><td colspan="6" class="empty">No hay movimientos en este período.</td></tr>`;

  const dailyMap = new Map();
  monthSales.forEach(sale => {
    const date = dayKey(sale.date);
    const key = `${date}__${sale.barberId}`;
    if (!dailyMap.has(key)) {
      dailyMap.set(key, {date, barberId:sale.barberId, barberName:sale.barberName || "Barbero", count:0, gross:0, pay:0, shop:0});
    }
    const row = dailyMap.get(key);
    row.count += 1;
    row.gross += Number(sale.total || 0);
    row.pay += Number(sale.barberAmount || 0);
    row.shop += Number(sale.shopAmount || 0);
  });

  const dailyRows = [...dailyMap.values()].sort((a,b) => {
    if (a.date !== b.date) return b.date.localeCompare(a.date);
    return a.barberName.localeCompare(b.barberName);
  });

  $("reportDailyBarbers").innerHTML = dailyRows.length ? dailyRows.map(r => `
    <tr>
      <td>${shortDayLabel(r.date)}</td>
      <td><b>${escapeHtml(r.barberName)}</b></td>
      <td>${r.count}</td>
      <td>${money(r.gross)}</td>
      <td class="money-positive"><b>${money(r.pay)}</b></td>
      <td>${money(r.shop)}</td>
    </tr>
  `).join("") : `<tr><td colspan="6" class="empty">No hay movimientos diarios en este período.</td></tr>`;

  renderBarberProfitFilter();
}

function renderBarberProfitFilter() {
  if (currentRole !== "admin") return;

  const select = $("barberProfitSelect");
  if (!select) return;

  const selectedMonth = $("barberProfitMonth")?.value || $("reportMonth")?.value || monthKey(new Date());
  const previous = select.value;
  const barbers = [...state.barbers].sort((a,b)=>(a.name||"").localeCompare(b.name||""));

  select.innerHTML = barbers.length
    ? barbers.map(b => `<option value="${b.id}">${escapeHtml(b.name || "Barbero")}</option>`).join("")
    : `<option value="">No hay barberos</option>`;

  if (previous && barbers.some(b => b.id === previous)) select.value = previous;

  const barberId = select.value || barbers[0]?.id || "";
  if (barberId) select.value = barberId;
  const barber = barbers.find(b => b.id === barberId);

  $("barberProfitPeriodLabel").textContent = `${barber?.name || "Barbero"} · ${monthLabel(selectedMonth)}`;

  const sales = state.sales
    .filter(s => monthKey(s.date) === selectedMonth && s.barberId === barberId)
    .sort((a,b)=>jsDate(b.date)-jsDate(a.date));

  const servicePay = sales.reduce((sum,s)=>sum + Number(s.serviceBarberAmount ?? s.barberAmount ?? 0),0);
  const productPay = sales.reduce((sum,s)=>sum + Number(s.productBarberAmount || 0),0);
  const totalPay = sales.reduce((sum,s)=>sum + Number(s.barberAmount || 0),0);

  $("barberProfitTotal").textContent = money(totalPay);
  $("barberProfitServices").textContent = money(servicePay);
  $("barberProfitProducts").textContent = money(productPay);
  $("barberProfitServiceCount").textContent = `${sales.length} servicio${sales.length===1?"":"s"}`;

  $("barberProfitRows").innerHTML = sales.length ? sales.map(s => `
    <tr>
      <td>${fmtDateTime(s.date)}</td>
      <td><b>${escapeHtml(s.serviceName || "Servicio")}</b></td>
      <td>${money(Number(s.serviceBarberAmount ?? s.barberAmount ?? 0))}</td>
      <td>${money(Number(s.productBarberAmount || 0))}</td>
      <td class="money-positive"><b>${money(Number(s.barberAmount || 0))}</b></td>
    </tr>
  `).join("") : `<tr><td colspan="5" class="empty">Este barbero no tiene ganancias registradas en el mes seleccionado.</td></tr>`;
}


function renderBarberChargeOptions() {
  if (currentRole !== "barber") return;

  const serviceSelect = $("barberChargeService");
  const chairInput = $("barberChargeChair");
  const productSelect = $("barberChargeProduct");
  const selectedService = serviceSelect.value;
  const selectedProduct = productSelect?.value || "";

  serviceSelect.innerHTML = state.services.length
    ? `<option value="">Selecciona un servicio...</option>` + state.services.map(s =>
        `<option value="${s.id}">${escapeHtml(s.name)} · ${money(s.price)}</option>`
      ).join("")
    : `<option value="">No hay servicios activos</option>`;

  if (productSelect) {
    const availableProducts = state.products.filter(p => Number(p.stock || 0) > 0);
    productSelect.innerHTML = availableProducts.length
      ? `<option value="">Selecciona un producto...</option>` + availableProducts.map(p =>
          `<option value="${p.id}">${escapeHtml(p.name)} · ${money(p.price)} · Stock ${Number(p.stock || 0)}</option>`
        ).join("")
      : `<option value="">No hay productos con existencia</option>`;
  }

  if (selectedService && state.services.some(s => s.id === selectedService)) {
    serviceSelect.value = selectedService;
  }
  if (selectedProduct && state.products.some(p => p.id === selectedProduct)) {
    productSelect.value = selectedProduct;
  }

  const fixedChair = state.chairs.find(c =>
    c.id === currentBarber?.chairId && c.active !== false
  );

  if (chairInput) chairInput.value = fixedChair?.id || "";

  const chairName = $("barberFixedChairName");
  const chairHelp = $("barberFixedChairHelp");
  const chairDisplay = $("barberFixedChairDisplay");

  if (fixedChair) {
    if (chairName) chairName.textContent = fixedChair.name;
    if (chairHelp) chairHelp.textContent = "Asignado por el administrador · se usa automáticamente.";
    chairDisplay?.classList.remove("chair-missing");
    chairDisplay?.classList.add("chair-ready");
  } else {
    if (chairName) chairName.textContent = currentBarber?.chairName || "Sin puesto asignado";
    if (chairHelp) chairHelp.textContent = currentBarber?.chairId
      ? "Tu puesto está inactivo. Solicita al administrador que te reasigne."
      : "El administrador debe asignarte un puesto antes de cobrar.";
    chairDisplay?.classList.remove("chair-ready");
    chairDisplay?.classList.add("chair-missing");
  }

  // Si no hay servicio seleccionado, usar automáticamente el primero del catálogo
  if (!serviceSelect.value && state.services.length) {
    serviceSelect.value = state.services[0].id;
  }

  const chosenService = state.services.find(s => s.id === serviceSelect.value);
  const priceInput = $("barberChargePrice");
  if (priceInput) {
    if (chosenService && (!priceInput.value || Number(priceInput.value) <= 0 || !selectedService)) {
      priceInput.value = Number(chosenService.price || 0).toFixed(2);
    }
  }

  renderBarberProductCart();
  renderBarberChargePreview();
}

function syncBarberChargePrice() {
  const service = state.services.find(s => s.id === $("barberChargeService").value);
  $("barberChargePrice").value = service ? Number(service.price || 0).toFixed(2) : "";
  renderBarberChargePreview();
}


function addProductToBarberCharge() {
  if (currentRole !== "barber") return;

  const productId = $("barberChargeProduct").value;
  const product = state.products.find(p => p.id === productId && p.active !== false);
  const qty = Math.max(1, Math.floor(Number($("barberChargeProductQty").value || 1)));

  if (!product) return toast("Selecciona un producto.");
  const stock = Math.max(0, Number(product.stock || 0));
  if (stock <= 0) return toast("Ese producto no tiene existencia.");

  const existing = barberProductCart.find(item => item.productId === product.id);
  const currentQty = Number(existing?.qty || 0);
  if (currentQty + qty > stock) return toast(`Solo hay ${stock} unidad${stock===1?"":"es"} disponibles.`);
  if (existing) {
    existing.qty += qty;
  } else {
    barberProductCart.push({
      productId:product.id,
      name:product.name,
      unitPrice:Number(product.price || 0),
      qty
    });
  }

  $("barberChargeProductQty").value = 1;
  renderBarberProductCart();
  renderBarberChargePreview();
}

function removeProductFromBarberCharge(productId) {
  barberProductCart = barberProductCart.filter(item => item.productId !== productId);
  renderBarberProductCart();
  renderBarberChargePreview();
}

function changeBarberProductQty(productId, delta) {
  const item = barberProductCart.find(x => x.productId === productId);
  if (!item) return;
  const product = state.products.find(p => p.id === productId);
  const stock = Math.max(0, Number(product?.stock || 0));
  const nextQty = Math.max(1, Number(item.qty || 1) + delta);
  if (delta > 0 && nextQty > stock) return toast(`Solo hay ${stock} unidad${stock===1?"":"es"} disponibles.`);
  item.qty = nextQty;
  renderBarberProductCart();
  renderBarberChargePreview();
}

function barberProductSubtotal() {
  return barberProductCart.reduce((sum,item) =>
    sum + Number(item.unitPrice || 0) * Number(item.qty || 0), 0
  );
}

function renderBarberProductCart() {
  const node = $("barberChargeProductCart");
  if (!node) return;

  node.innerHTML = barberProductCart.length ? barberProductCart.map(item => `
    <div class="barber-product-line">
      <div class="barber-product-line-info">
        <span class="product-sale-icon">▦</span>
        <div>
          <strong>${escapeHtml(item.name)}</strong>
          <small>${money(item.unitPrice)} c/u</small>
        </div>
      </div>
      <div class="product-qty-control">
        <button type="button" data-product-minus="${item.productId}">−</button>
        <b>${item.qty}</b>
        <button type="button" data-product-plus="${item.productId}">+</button>
      </div>
      <strong class="product-line-total">${money(item.unitPrice * item.qty)}</strong>
      <button type="button" class="product-remove-btn" data-product-remove="${item.productId}" aria-label="Eliminar producto">×</button>
    </div>
  `).join("") : `
    <div class="barber-product-empty">
      <span>▦</span>
      <div><strong>Sin productos</strong><small>Puedes enviar solo el servicio o agregar productos vendidos.</small></div>
    </div>`;

  document.querySelectorAll("[data-product-remove]").forEach(btn =>
    btn.addEventListener("click", () => removeProductFromBarberCharge(btn.dataset.productRemove))
  );
  document.querySelectorAll("[data-product-plus]").forEach(btn =>
    btn.addEventListener("click", () => changeBarberProductQty(btn.dataset.productPlus, 1))
  );
  document.querySelectorAll("[data-product-minus]").forEach(btn =>
    btn.addEventListener("click", () => changeBarberProductQty(btn.dataset.productMinus, -1))
  );
}

function renderBarberChargePreview() {
  if (currentRole !== "barber") return;

  const service = state.services.find(s => s.id === $("barberChargeService").value);
  const chair = state.chairs.find(c => c.id === currentBarber?.chairId && c.active !== false);
  const servicePrice = Math.max(0, Number($("barberChargePrice").value || 0));
  const productsTotal = barberProductSubtotal();
  const total = servicePrice + productsTotal;
  const payment = $("barberChargePayment").value || "Efectivo";

  const serviceCommission = Number(currentBarber?.commission ?? 50);
  const productCommission = Number(currentBarber?.productCommission ?? 0);

  const serviceBarberAmount = servicePrice * serviceCommission / 100;
  const productBarberAmount = productsTotal * productCommission / 100;
  const barberAmount = serviceBarberAmount + productBarberAmount;
  const shopAmount = total - barberAmount;

  $("barberChargeServicePreview").textContent = service?.name || "Selecciona un servicio";
  $("barberChargeChairPreview").textContent = chair?.name || "Puesto no asignado";
  $("barberChargeTotalPreview").textContent = money(total);
  $("barberChargePaymentPreview").textContent = payment;

  $("barberChargeBarberPreview").textContent = money(barberAmount);
  $("barberChargeShopPreview").textContent = money(shopAmount);

  const productsSubtotalNode = $("barberChargeProductsSubtotalPreview");
  const productsPreviewNode = $("barberChargeProductsPreview");
  if (productsSubtotalNode) productsSubtotalNode.textContent = money(productsTotal);
  if (productsPreviewNode) {
    productsPreviewNode.innerHTML = barberProductCart.length
      ? barberProductCart.map(item => `<div><span>${item.qty}× ${escapeHtml(item.name)}</span><b>${money(item.unitPrice * item.qty)}</b></div>`).join("")
      : `<small>Sin productos agregados</small>`;
  }
}

async function submitBarberChargeRequest(e) {
  e.preventDefault();
  if (currentRole !== "barber" || !currentBarber) return;

  const service = state.services.find(s => s.id === $("barberChargeService").value);
  const chair = state.chairs.find(c => c.id === currentBarber?.chairId && c.active !== false);
  const servicePrice = Number($("barberChargePrice").value);
  const products = barberProductCart.map(item => ({
    productId:item.productId,
    name:item.name,
    unitPrice:+Number(item.unitPrice || 0).toFixed(2),
    qty:Number(item.qty || 0),
    subtotal:+(Number(item.unitPrice || 0) * Number(item.qty || 0)).toFixed(2)
  }));
  const productTotal = +barberProductSubtotal().toFixed(2);
  const total = +(Number(servicePrice || 0) + productTotal).toFixed(2);
  const payment = $("barberChargePayment").value;
  const note = $("barberChargeNote").value.trim();

  if (!service || !chair || !servicePrice || servicePrice <= 0 || !payment) {
    return toast(!chair ? "No tienes un puesto fijo activo. Solicita al administrador que te asigne uno." : "Revisa servicio, precio y método de pago.");
  }

  try {
    await setDoc(doc(collection(db, "chargeRequests")), {
      barberId:auth.currentUser.uid,
      barberName:currentBarber.name || "Barbero",
      chairId:chair.id,
      chairName:chair.name,
      serviceId:service.id,
      serviceName:service.name,
      servicePrice:+servicePrice.toFixed(2),
      products,
      productTotal,
      price:total,
      payment,
      serviceCommissionPreview:Number(currentBarber.commission ?? 50),
      productCommissionPreview:Number(currentBarber.productCommission ?? 0),
      note,
      status:"pending",
      requestedAt:serverTimestamp(),
      createdBy:auth.currentUser.uid
    });

    e.target.reset();
    barberProductCart = [];
    renderBarberChargeOptions();
    renderBarberProductCart();
    renderBarberChargePreview();
    toast("Cobro con servicio y productos enviado al administrador.");
  } catch (err) {
    console.error(err);
    toast(firebaseErrorMessage(err, "No se pudo enviar el cobro al administrador."));
  }
}

function renderMyChargeRequests() {
  if (currentRole !== "barber") return;

  const requests = [...state.chargeRequests].sort((a,b) => jsDate(b.requestedAt) - jsDate(a.requestedAt)).slice(0,12);
  $("myChargeRequests").innerHTML = requests.length ? requests.map(r => {
    const status = r.status || "pending";
    const statusText = statusLabel(status);
    const credited = status === "approved" ? money(r.barberAmount || 0) : "—";
    return `
      <div class="barber-charge-row">
        <div class="barber-charge-icon ${status}">${status === "approved" ? "✓" : status === "rejected" ? "×" : "↗"}</div>
        <div class="barber-charge-info">
          <div class="barber-charge-title">${escapeHtml(r.serviceName || "Servicio")} · ${money(r.price)}</div>
          <div class="item-meta">${escapeHtml(r.chairName || "")} · ${escapeHtml(r.payment || "")} · ${r.requestedAt ? fmtDateTime(r.requestedAt) : "Enviado ahora"}</div>
        </div>
        <div class="barber-charge-credit">
          <span class="request-status ${status}">${statusText}</span>
          <small>${status === "approved" ? `Acreditado: ${credited}` : status === "rejected" ? "No acreditado" : "Esperando confirmación"}</small>
        </div>
      </div>`;
  }).join("") : `<div class="empty">Todavía no has enviado trabajos a Caja.</div>`;
}

function setBarberServiceView(mode) {
  barberServiceViewMode = mode === "table" ? "table" : "cards";
  document.querySelectorAll("[data-service-view]").forEach(btn =>
    btn.classList.toggle("active", btn.dataset.serviceView === barberServiceViewMode)
  );
  if (currentRole === "barber") renderBarberPortal();
}

function renderBarberRecentServices(recent) {
  const node = $("mySales");
  if (!node) return;

  document.querySelectorAll("[data-service-view]").forEach(btn =>
    btn.classList.toggle("active", btn.dataset.serviceView === barberServiceViewMode)
  );

  if (!recent.length) {
    node.className = "premium-service-list";
    node.innerHTML = `
      <div class="premium-empty-state">
        <span>✂</span>
        <strong>Aún no tienes servicios registrados</strong>
        <small>Cuando el administrador confirme tus cobros aparecerán aquí.</small>
      </div>`;
    return;
  }

  if (barberServiceViewMode === "table") {
    node.className = "barber-service-table-wrap";
    node.innerHTML = `
      <div class="table-wrap">
        <table class="premium-report-table barber-service-table">
          <thead>
            <tr>
              <th>Fecha / hora</th>
              <th>Servicio</th>
              <th>Método</th>
              <th>Servicios</th>
              <th>Productos</th>
              <th>Para ti</th>
            </tr>
          </thead>
          <tbody>
            ${recent.map(s => {
              const dt = jsDate(s.date);
              const time = dt.toLocaleTimeString("es-PA", {hour:"2-digit",minute:"2-digit"});
              const day = dt.toLocaleDateString("es-PA", {day:"2-digit",month:"short",year:"numeric"});
              const servicePay = Number(s.serviceBarberAmount ?? s.barberAmount ?? 0);
              const productPay = Number(s.productBarberAmount || 0);
              return `
                <tr>
                  <td><b>${escapeHtml(time)}</b><small class="table-date-sub">${escapeHtml(day)}</small></td>
                  <td><b>${escapeHtml(s.serviceName || "Servicio")}</b><small class="table-status-sub">Acreditado</small></td>
                  <td>${escapeHtml(s.payment || "—")}</td>
                  <td>${money(servicePay)}</td>
                  <td>${money(productPay)}</td>
                  <td class="money-positive"><b>${money(s.barberAmount)}</b></td>
                </tr>`;
            }).join("")}
          </tbody>
        </table>
      </div>`;
    return;
  }

  node.className = "premium-service-list premium-service-card-grid";
  node.innerHTML = recent.map((s,index) => {
    const dt = jsDate(s.date);
    const time = dt.toLocaleTimeString("es-PA", {hour:"2-digit",minute:"2-digit"});
    const day = dt.toLocaleDateString("es-PA", {day:"2-digit",month:"short"});
    const servicePay = Number(s.serviceBarberAmount ?? s.barberAmount ?? 0);
    const productPay = Number(s.productBarberAmount || 0);
    const productsCount = Array.isArray(s.products)
      ? s.products.reduce((sum,p)=>sum+Number(p.qty||0),0)
      : 0;

    return `
      <article class="barber-service-card">
        <div class="barber-service-card-head">
          <div class="barber-service-time-pill">
            <strong>${escapeHtml(time)}</strong>
            <span>${escapeHtml(day)}</span>
          </div>
          <span class="service-credit-status">ACREDITADO</span>
        </div>

        <div class="barber-service-card-title">
          <span>#${String(index+1).padStart(2,"0")}</span>
          <h4>${escapeHtml(s.serviceName || "Servicio")}</h4>
          <small>${escapeHtml(s.payment || "—")}${productsCount ? ` · ${productsCount} producto${productsCount===1?"":"s"}` : " · Sin productos"}</small>
        </div>

        <div class="barber-service-earnings">
          <div><span>Servicios</span><strong>${money(servicePay)}</strong></div>
          <div><span>Productos</span><strong>${money(productPay)}</strong></div>
        </div>

        <div class="barber-service-total">
          <span>ACREDITADO PARA TI</span>
          <strong>${money(s.barberAmount)}</strong>
        </div>
      </article>`;
  }).join("");
}

function renderBarberAvailabilityState() {
  const badge = $("barberAvailabilityBadge");
  const btn = $("toggleBarberAvailabilityBtn");
  if (!badge || !btn) return;

  btn.className = "barber-availability-btn premium";

  const chair = state.chairs.find(c => c.id === currentBarber?.chairId);
  if (!chair) {
    badge.className = "barber-availability-pill offline";
    badge.textContent = "Sin puesto";
    btn.textContent = "Sin puesto asignado";
    btn.disabled = true;
    btn.classList.add("offline-state");
    return;
  }

  const status = chairOperationalStatus(chair);
  badge.className = `barber-availability-pill ${status.key}`;
  badge.textContent = status.key === "occupied" ? "Ocupado" : status.key === "available" ? "Disponible" : status.label;

  if (status.source === "appointment") {
    btn.textContent = "Ocupado por cita";
    btn.disabled = true;
    btn.classList.add("offline-state");
    return;
  }

  if (chair.active === false || status.key === "offline") {
    btn.textContent = "Puesto fuera de servicio";
    btn.disabled = true;
    btn.classList.add("offline-state");
    return;
  }

  btn.disabled = false;
  if (chair.operationalStatus === "occupied") {
    btn.textContent = "Marcar disponible";
    btn.classList.add("available-state");
  } else {
    btn.textContent = "Marcar ocupado";
    btn.classList.add("occupied-state");
  }
}

async function toggleCurrentBarberChairOccupied() {
  if (currentRole !== "barber" || !currentBarber?.chairId) return toast("No tienes un puesto asignado.");
  const btn = $("toggleBarberAvailabilityBtn");
  const badge = $("barberAvailabilityBadge");
  btn?.classList.add("state-changing");
  badge?.classList.add("state-changing");
  try {
    await toggleChairOccupied(currentBarber.chairId);
  } finally {
    setTimeout(() => {
      btn?.classList.remove("state-changing");
      badge?.classList.remove("state-changing");
    }, 520);
  }
}

function renderBarberPortal() {
  if (currentRole !== "barber" || !currentBarber) return;

  renderBarberChargeOptions();
  renderMyChargeRequests();

  $("barberWelcomeName").textContent = (currentBarber.name || "Barbero").split(" ")[0];
  $("barberWelcomeChair").textContent = currentBarber.chairName || "Puesto sin asignar";
  renderBarberAvailabilityState();

  const mine = state.sales.filter(s => s.barberId === currentBarber.id);
  const today = mine.filter(s => todayIso(s.date));
  const currentMonth = monthKey(new Date());
  const thisMonth = mine.filter(s => monthKey(s.date) === currentMonth);

  const todayServicePay = today.reduce((a,s)=>a+Number(s.serviceBarberAmount ?? s.barberAmount ?? 0),0);
  const todayProductPay = today.reduce((a,s)=>a+Number(s.productBarberAmount || 0),0);
  const todayPay = today.reduce((a,s)=>a+Number(s.barberAmount||0),0);
  const monthPay = thisMonth.reduce((a,s)=>a+Number(s.barberAmount||0),0);

  $("myTodayGross").textContent = money(todayPay);
  $("myTodayPay").textContent = money(todayServicePay);
  $("myMonthGross").textContent = money(todayProductPay);
  $("myMonthPay").textContent = money(monthPay);
  $("myAllPay").textContent = money(mine.reduce((a,s)=>a+Number(s.barberAmount||0),0));
  $("myTodayCount").textContent = `${today.length} servicio${today.length===1?"":"s"} hoy`;
  $("myMonthCount").textContent = `${thisMonth.length} servicio${thisMonth.length===1?"":"s"} este mes`;
  $("myMonthLabel").textContent = monthLabel(currentMonth);

  const daily = new Map();
  thisMonth.forEach(sale => {
    const date = dayKey(sale.date);
    if (!daily.has(date)) daily.set(date, {date, count:0, servicePay:0, productPay:0, pay:0});
    const row = daily.get(date);
    row.count += 1;
    row.servicePay += Number(sale.serviceBarberAmount ?? sale.barberAmount ?? 0);
    row.productPay += Number(sale.productBarberAmount || 0);
    row.pay += Number(sale.barberAmount || 0);
  });

  const dailyRows = [...daily.values()].sort((a,b)=>b.date.localeCompare(a.date));
  $("myDailyBalances").innerHTML = dailyRows.length ? dailyRows.map(r => `
    <tr>
      <td>${shortDayLabel(r.date)}</td>
      <td>${r.count}</td>
      <td>${money(r.servicePay)}</td>
      <td>${money(r.productPay)}</td>
      <td class="money-positive"><b>${money(r.pay)}</b></td>
    </tr>
  `).join("") : `<tr><td colspan="5" class="empty">Aún no tienes servicios este mes.</td></tr>`;

  const appts = state.appointments
    .filter(a => !["cancelled","completed"].includes(a.status) && a.date >= isoDay())
    .sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));

  const todayAppts = appts.filter(a=>a.date===isoDay());
  $("myTodayAppointments").textContent = todayAppts.length;
  renderBarberTodayAppointmentsModal();

  $("myAppointments").innerHTML = appts.length ? appts.map(a => `
    <div class="list-row">
      <div>
        <div class="item-title">${escapeHtml(a.clientName)} · ${escapeHtml(a.serviceName)}</div>
        <div class="item-meta">${fmtDateOnly(a.date)} ${a.time} · ${escapeHtml(a.clientPhone)}</div>
      </div>
      <div class="barber-appt-actions">
        <span class="status ${a.status}">${statusLabel(a.status)}</span>
        ${a.status==="pending"?`<button class="tiny-btn" data-myappt="${a.id}" data-status="confirmed" type="button">Confirmar</button>`:""}
        ${a.status==="confirmed"?`<button class="tiny-btn" data-myappt="${a.id}" data-status="completed" type="button">Completar</button>`:""}
      </div>
    </div>
  `).join("") : `<div class="empty">No tienes citas próximas.</div>`;

  document.querySelectorAll("[data-myappt]").forEach(btn =>
    btn.addEventListener("click", () => changeAppointment(btn.dataset.myappt, btn.dataset.status))
  );

  const recent = [...mine].sort((a,b)=>jsDate(b.date)-jsDate(a.date)).slice(0,8);
  renderBarberRecentServices(recent);
}

function openBarberTodayAppointmentsModal() {
  renderBarberTodayAppointmentsModal();
  openModal("barberTodayAppointmentsModal");
}

function renderBarberTodayAppointmentsModal() {
  if (currentRole !== "barber") return;
  const node = $("barberTodayAppointmentsList");
  if (!node) return;

  const today = state.appointments
    .filter(a => a.date === isoDay() && !["completed","cancelled"].includes(a.status))
    .sort((a,b)=>(a.time||"").localeCompare(b.time||""));

  $("barberTodayAppointmentsCount").textContent = today.length;
  $("barberTodayAppointmentsDateLabel").textContent = new Date().toLocaleDateString("es-PA", {
    weekday:"long", day:"2-digit", month:"long", year:"numeric"
  });

  node.innerHTML = today.length ? today.map((a,index) => `
    <article class="barber-premium-appt-card ${a.status}">
      <div class="barber-appt-time-block">
        <span>CITA ${String(index+1).padStart(2,"0")}</span>
        <strong>${escapeHtml(a.time || "")}</strong>
      </div>

      <div class="barber-appt-info">
        <div class="barber-appt-info-top">
          <div>
            <span class="barber-appt-client-label">CLIENTE</span>
            <h4>${escapeHtml(a.clientName || "Cliente")}</h4>
          </div>
          <span class="status ${a.status}">${statusLabel(a.status)}</span>
        </div>

        <div class="barber-appt-detail-grid">
          <div>
            <span>Servicio</span>
            <strong>${escapeHtml(a.serviceName || "Servicio")}</strong>
          </div>
          <div>
            <span>Teléfono</span>
            <strong>${escapeHtml(a.clientPhone || "Sin teléfono")}</strong>
          </div>
          <div>
            <span>Puesto</span>
            <strong>${escapeHtml(currentBarber?.chairName || "Puesto asignado")}</strong>
          </div>
        </div>

        ${a.note ? `<div class="barber-appt-note"><span>NOTA</span><p>${escapeHtml(a.note)}</p></div>` : ""}
      </div>

      <div class="barber-appt-modal-actions">
        ${a.status==="pending" ? `<button class="appt-action-primary" data-myapptmodal="${a.id}" data-status="confirmed" type="button">✓ Confirmar cita</button>` : ""}
        ${a.status==="confirmed" ? `<button class="appt-action-primary complete" data-myapptmodal="${a.id}" data-status="completed" type="button">✓ Marcar completada</button>` : ""}
        ${a.status==="completed" ? `<span class="appt-done-chip">SERVICIO COMPLETADO</span>` : ""}
      </div>
    </article>
  `).join("") : `
    <div class="barber-premium-empty-appts">
      <span>◷</span>
      <strong>No tienes citas programadas para hoy</strong>
      <p>Tu agenda del día está libre.</p>
    </div>`;

  document.querySelectorAll("[data-myapptmodal]").forEach(btn =>
    btn.addEventListener("click", () => changeAppointment(btn.dataset.myapptmodal, btn.dataset.status))
  );
}

function renderClientOptions() {
  if (currentRole !== "client") return;

  $("clientServiceOptions").innerHTML = state.services.length ? state.services.map(s => `
    <button type="button" class="choice service-choice ${booking.serviceId===s.id?"selected":""}" data-service="${s.id}">
      <strong>${escapeHtml(s.name)}</strong>
      <small>${money(s.price)} · ${Number(s.duration||30)} min</small>
    </button>
  `).join("") : `<div class="empty">No hay servicios disponibles.</div>`;

  const anyChoice = `
    <button type="button" class="choice barber-choice any-barber-choice ${booking.barberId===ANY_BARBER?"selected":""}" data-barber="${ANY_BARBER}">
      <strong>Sin preferencia</strong>
      <small>El administrador asignará un barbero disponible</small>
    </button>`;

  $("clientBarberOptions").innerHTML = state.barbers.length
    ? anyChoice + state.barbers.map(b => `
        <button type="button" class="choice barber-choice ${booking.barberId===b.id?"selected":""}" data-barber="${b.id}">
          <strong>${escapeHtml(b.name)}</strong>
          <small>${escapeHtml(b.chairName || "Barbero disponible")}</small>
        </button>
      `).join("")
    : `<div class="empty">No hay barberos disponibles.</div>`;

  document.querySelectorAll(".service-choice").forEach(btn =>
    btn.addEventListener("click", () => {
      booking.serviceId = btn.dataset.service;
      renderClientOptions();
    })
  );

  document.querySelectorAll(".barber-choice").forEach(btn =>
    btn.addEventListener("click", () => {
      booking.barberId = btn.dataset.barber;
      renderClientOptions();
      renderAvailableTimes();
    })
  );

  renderAvailableTimes();
}

function openClientDatePicker() {
  const input = $("clientDate");
  if (!input) return;
  try {
    if (typeof input.showPicker === "function") input.showPicker();
    else {
      input.focus();
      input.click();
    }
  } catch (_) {
    input.focus();
    input.click();
  }
}

function setClientDateOffset(offset) {
  const d = new Date();
  d.setHours(12,0,0,0);
  d.setDate(d.getDate() + Number(offset || 0));
  $("clientDate").value = isoDay(d);
  updateSelectedDateSummary();
  renderAvailableTimes();
}

function updateSelectedDateSummary() {
  const input = $("clientDate");
  const box = $("selectedDateSummary");
  if (!input || !box) return;
  if (!input.value) {
    box.textContent = "Selecciona una fecha para ver horarios disponibles.";
    return;
  }
  const [y,m,d] = input.value.split("-").map(Number);
  const selected = new Date(y,m-1,d);
  box.innerHTML = `<span>✓</span><div><b>${selected.toLocaleDateString("es-PA", {weekday:"long", day:"2-digit", month:"long", year:"numeric"})}</b><small>Ahora selecciona un barbero para consultar sus horas disponibles.</small></div>`;
}

function isSlotOccupiedForBarber(barberId, day, time) {
  return state.bookedSlots.some(s =>
    s.date === day &&
    s.time === time &&
    s.barberId === barberId &&
    s.status !== "cancelled"
  );
}

function availableBarbersForSlot(day, time) {
  return state.barbers.filter(b =>
    b.active !== false && !isSlotOccupiedForBarber(b.id, day, time)
  );
}

function renderAvailableTimes() {
  if (currentRole !== "client") return;

  const day = $("clientDate").value;
  const barberId = booking.barberId;
  const select = $("clientTime");

  if (!day || !barberId) {
    select.innerHTML = `<option value="">Selecciona fecha y barbero</option>`;
    return;
  }

  const slots = [];
  const now = new Date();
  const isToday = day === isoDay(now);
  const minMinutesToday = (now.getHours() * 60) + now.getMinutes() + 30;

  for (let h=9; h<19; h++) {
    for (const m of [0,30]) {
      const t = `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
      const slotMinutes = (h * 60) + m;
      const isPast = isToday && slotMinutes < minMinutesToday;
      if (isPast) continue;

      const available = barberId === ANY_BARBER
        ? availableBarbersForSlot(day, t).length > 0
        : !isSlotOccupiedForBarber(barberId, day, t);

      if (available) slots.push(t);
    }
  }

  select.innerHTML = slots.length
    ? `<option value="">Selecciona una hora</option>${slots.map(t=>`<option value="${t}">${t}</option>`).join("")}`
    : `<option value="">Sin horarios disponibles para esta fecha</option>`;
}

function slotId(barberId, day, time) {
  return `${barberId}_${day}_${time.replace(":","")}`;
}

async function createAppointment(e) {
  e.preventDefault();

  if (!auth.currentUser?.isAnonymous) return toast("Vuelve al inicio y entra nuevamente como Cliente.");

  const service = state.services.find(s => s.id === booking.serviceId);
  const day = $("clientDate").value;
  const time = $("clientTime").value;
  const wantsAny = booking.barberId === ANY_BARBER;

  if (!service) return toast("Selecciona un servicio.");
  if (!booking.barberId) return toast("Selecciona un barbero o 'Sin preferencia'.");
  if (!day || !time) return toast("Selecciona fecha y hora.");

  const candidates = wantsAny
    ? availableBarbersForSlot(day, time)
    : state.barbers.filter(b => b.id === booking.barberId);

  if (!candidates.length) {
    renderAvailableTimes();
    return toast("No hay barberos disponibles en ese horario.");
  }

  const apptRef = doc(collection(db, "appointments"));
  let reserved = false;

  for (const candidate of candidates) {
    const id = slotId(candidate.id, day, time);
    const slotRef = doc(db, "bookedSlots", id);

    try {
      await runTransaction(db, async tx => {
        const slotSnap = await tx.get(slotRef);
        if (slotSnap.exists() && slotSnap.data().status !== "cancelled") {
          throw new Error("SLOT_TAKEN");
        }

        const baseSlot = {
          slotId:id,
          ownerUid:auth.currentUser.uid,
          barberId:candidate.id,
          date:day,
          time,
          status:"pending",
          createdAt:serverTimestamp(),
          updatedAt:serverTimestamp()
        };

        tx.set(slotRef, baseSlot);
        tx.set(apptRef, {
          ...baseSlot,
          clientName:$("clientName").value.trim(),
          clientPhone:$("clientPhone").value.trim(),
          serviceId:service.id,
          serviceName:service.name,
          servicePrice:Number(service.price),

          // Si el cliente no tiene preferencia, el puesto se reserva
          // internamente para evitar sobreventa, pero el admin decide
          // qué barbero quedará finalmente asignado.
          barberId:wantsAny ? "unassigned" : candidate.id,
          barberName:wantsAny ? "Por asignar" : candidate.name,
          reservedBarberId:candidate.id,
          needsAssignment:wantsAny,

          note:$("clientNote").value.trim()
        });
      });

      reserved = true;
      break;
    } catch (err) {
      if (!String(err?.message).includes("SLOT_TAKEN")) throw err;
    }
  }

  if (!reserved) {
    renderAvailableTimes();
    return toast("Ese horario acaba de llenarse. Elige otro.");
  }

  e.target.reset();
  booking = { serviceId:null, barberId:null };
  $("clientDate").value = isoDay();
  updateSelectedDateSummary();
  renderClientOptions();
  toast(wantsAny
    ? "¡Cita reservada! El administrador asignará tu barbero."
    : "¡Cita reservada! Pendiente de confirmación."
  );
}

function renderClientAppointments() {
  if (currentRole !== "client") return;
  const rows = [...state.clientAppointments].sort((a,b)=>(b.date+b.time).localeCompare(a.date+a.time));
  $("clientAppointments").innerHTML = rows.length ? rows.map(a => `
    <div class="client-appt"><strong>${fmtDateOnly(a.date)} · ${a.time}</strong><small>${escapeHtml(a.serviceName)} · ${appointmentNeedsBarber(a) ? "Barbero por asignar" : `con ${escapeHtml(a.barberName)}`} · ${statusLabel(a.status)}</small></div>
  `).join("") : `<div class="empty">Aún no has creado citas desde este dispositivo.</div>`;
}

function exportCsv() {
  const selectedMonth = $("reportMonth")?.value || monthKey(new Date());
  const rows = state.sales
    .filter(s => monthKey(s.date) === selectedMonth)
    .sort((a,b)=>jsDate(a.date)-jsDate(b.date));

  const header = ["Fecha","Barbero","Puesto","Servicio","Metodo","Total cobrado","Comision %","Saldo barbero","Ingreso barberia"];
  const data = rows.map(s => [
    jsDate(s.date).toLocaleString("es-PA"),
    s.barberName,
    s.chairName,
    s.serviceName,
    s.payment,
    Number(s.total || 0).toFixed(2),
    Number(s.commission || 0).toFixed(2),
    Number(s.barberAmount || 0).toFixed(2),
    Number(s.shopAmount || 0).toFixed(2)
  ]);

  const csv = [header,...data]
    .map(r => r.map(v => `"${String(v ?? "").replaceAll('"','""')}"`).join(","))
    .join("\\n");

  const blob = new Blob(["\\ufeff"+csv], { type:"text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Los_Magicos_Reporte_${selectedMonth}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}


async function exportExcelReport() {
  if (!window.ExcelJS) {
    return toast("No se pudo cargar el generador de Excel. Revisa tu conexión a Internet.");
  }

  const period = dashboardPeriod();
  const selectedMonth = period.start.slice(0,7);
  const periodLabel = period.label;
  const monthSales = state.sales
    .filter(s => saleInDashboardPeriod(s, period))
    .sort((a,b) => jsDate(a.date) - jsDate(b.date));

  if (!monthSales.length) {
    return toast("No hay cobros en el período seleccionado para exportar.");
  }

  toast("Generando Excel premium...");

  try {
    const ExcelJS = window.ExcelJS;
    const wb = new ExcelJS.Workbook();
    wb.creator = "Barbería Los Mágicos";
    wb.lastModifiedBy = "Barbería Los Mágicos";
    wb.created = new Date();
    wb.modified = new Date();
    wb.subject = `Reporte ${periodLabel}`;
    wb.title = `Barbería Los Mágicos - ${periodLabel}`;

    const COLORS = {
      black: "FF111114",
      dark: "FF1D1D21",
      gold: "FFD7AD56",
      goldSoft: "FFF4E6C8",
      white: "FFFFFFFF",
      text: "FF171717",
      muted: "FF666666",
      light: "FFF7F7F7",
      border: "FFD9D9D9",
      green: "FF1F7A4D"
    };

    const currencyFmt = '$#,##0.00';
    const pctFmt = '0.00%';

    function setTitle(ws, title, subtitle, endCol = 6) {
      ws.mergeCells(1, 1, 2, endCol);
      const titleCell = ws.getCell(1, 1);
      titleCell.value = "BARBERÍA LOS MÁGICOS";
      titleCell.font = { name:"Aptos Display", size:22, bold:true, color:{argb:COLORS.gold} };
      titleCell.fill = { type:"pattern", pattern:"solid", fgColor:{argb:COLORS.black} };
      titleCell.alignment = { vertical:"middle", horizontal:"left" };

      ws.mergeCells(3, 1, 3, endCol);
      const sub = ws.getCell(3, 1);
      sub.value = title;
      sub.font = { name:"Aptos", size:14, bold:true, color:{argb:COLORS.text} };

      ws.mergeCells(4, 1, 4, endCol);
      const desc = ws.getCell(4, 1);
      desc.value = subtitle;
      desc.font = { name:"Aptos", size:10, color:{argb:COLORS.muted} };

      ws.getRow(1).height = 28;
      ws.getRow(2).height = 28;
      ws.getRow(3).height = 22;
      ws.getRow(4).height = 18;
    }

    function styleHeader(row) {
      row.eachCell(cell => {
        cell.fill = { type:"pattern", pattern:"solid", fgColor:{argb:COLORS.dark} };
        cell.font = { name:"Aptos", size:10, bold:true, color:{argb:COLORS.white} };
        cell.alignment = { vertical:"middle", horizontal:"center" };
        cell.border = {
          top:{style:"thin", color:{argb:COLORS.border}},
          bottom:{style:"thin", color:{argb:COLORS.border}},
          left:{style:"thin", color:{argb:COLORS.border}},
          right:{style:"thin", color:{argb:COLORS.border}}
        };
      });
      row.height = 22;
    }

    function styleDataRows(ws, startRow, endRow, moneyCols = []) {
      for (let r = startRow; r <= endRow; r++) {
        const row = ws.getRow(r);
        row.eachCell(cell => {
          cell.font = { name:"Aptos", size:10, color:{argb:COLORS.text} };
          cell.border = {
            bottom:{style:"hair", color:{argb:"FFE5E5E5"}}
          };
          cell.alignment = { vertical:"middle" };
        });
        moneyCols.forEach(c => {
          row.getCell(c).numFmt = currencyFmt;
        });
      }
    }

    function addKpi(ws, row, col, label, value, gold = false) {
      ws.mergeCells(row, col, row, col + 1);
      const labelCell = ws.getCell(row, col);
      labelCell.value = label;
      labelCell.font = { size:9, bold:true, color:{argb:gold ? COLORS.text : COLORS.muted} };
      labelCell.fill = {
        type:"pattern",
        pattern:"solid",
        fgColor:{argb:gold ? COLORS.goldSoft : COLORS.light}
      };
      labelCell.alignment = { horizontal:"left", vertical:"middle" };

      ws.mergeCells(row + 1, col, row + 2, col + 1);
      const valueCell = ws.getCell(row + 1, col);
      valueCell.value = value;
      valueCell.numFmt = currencyFmt;
      valueCell.font = { size:19, bold:true, color:{argb:gold ? "FF8A611D" : COLORS.text} };
      valueCell.fill = {
        type:"pattern",
        pattern:"solid",
        fgColor:{argb:gold ? COLORS.goldSoft : COLORS.light}
      };
      valueCell.alignment = { horizontal:"left", vertical:"middle" };

      for (let rr = row; rr <= row + 2; rr++) {
        for (let cc = col; cc <= col + 1; cc++) {
          ws.getCell(rr, cc).border = {
            top:{style:"thin", color:{argb:COLORS.border}},
            bottom:{style:"thin", color:{argb:COLORS.border}},
            left:{style:"thin", color:{argb:COLORS.border}},
            right:{style:"thin", color:{argb:COLORS.border}}
          };
        }
      }
    }

    const total = monthSales.reduce((a,s)=>a+Number(s.total||0),0);
    const barberTotal = monthSales.reduce((a,s)=>a+Number(s.barberAmount||0),0);
    const shopTotal = monthSales.reduce((a,s)=>a+Number(s.shopAmount||0),0);
    const average = monthSales.length ? +(total / monthSales.length).toFixed(2) : 0;
  
    const chairRows = state.chairs.map(chair => {
      const sales = monthSales.filter(s => s.chairId === chair.id);
      return {
        name: chair.name,
        count: sales.length,
        gross: sales.reduce((a,s)=>a+Number(s.total||0),0),
        barber: sales.reduce((a,s)=>a+Number(s.barberAmount||0),0),
        shop: sales.reduce((a,s)=>a+Number(s.shopAmount||0),0)
      };
    }).sort((a,b)=>b.gross-a.gross);

    const barberMonthly = state.barbers.map(barber => {
      const sales = monthSales.filter(s => s.barberId === barber.id);
      return {
        id: barber.id,
        name: barber.name,
        commission: Number(barber.commission ?? 50),
        count: sales.length,
        gross: sales.reduce((a,s)=>a+Number(s.total||0),0),
        pay: sales.reduce((a,s)=>a+Number(s.barberAmount||0),0),
        shop: sales.reduce((a,s)=>a+Number(s.shopAmount||0),0)
      };
    }).sort((a,b)=>b.gross-a.gross);

    const dailyMap = new Map();
    monthSales.forEach(sale => {
      const date = dayKey(sale.date);
      const key = `${date}__${sale.barberId}`;
      if (!dailyMap.has(key)) {
        dailyMap.set(key, {
          date,
          barberName: sale.barberName || "Barbero",
          count:0, gross:0, pay:0, shop:0
        });
      }
      const row = dailyMap.get(key);
      row.count += 1;
      row.gross += Number(sale.total||0);
      row.pay += Number(sale.barberAmount||0);
      row.shop += Number(sale.shopAmount||0);
    });
    const dailyRows = [...dailyMap.values()].sort((a,b) => {
      if (a.date !== b.date) return a.date.localeCompare(b.date);
      return a.barberName.localeCompare(b.barberName);
    });

    // =====================================================
    // HOJA 1: RESUMEN
    // =====================================================
    const summary = wb.addWorksheet("Resumen", {
      properties:{ tabColor:{argb:COLORS.gold} },
      pageSetup:{ orientation:"landscape", fitToPage:true, fitToWidth:1, fitToHeight:0 }
    });
    setTitle(
      summary,
      `Reporte mensual · ${periodLabel}`,
      `Generado el ${new Date().toLocaleString("es-PA")} · ${monthSales.length} servicios`,
      8
    );

    addKpi(summary, 6, 1, "TOTAL COBRADO", total);
    addKpi(summary, 6, 3, "PAGO A BARBEROS", barberTotal);
    addKpi(summary, 6, 5, "INGRESO BARBERÍA", shopTotal, true);
    addKpi(summary, 6, 7, "TICKET PROMEDIO", average);

    summary.getCell("A11").value = "DETALLE POR PUESTO";
    summary.getCell("A11").font = { size:13, bold:true, color:{argb:COLORS.text} };

    const chairHeaderRow = 12;
    const chairHeaders = ["Puesto","Servicios","Total cobrado","Pago barberos","Ingreso barbería"];
    chairHeaders.forEach((h,i)=>summary.getCell(chairHeaderRow, i+1).value = h);
    styleHeader(summary.getRow(chairHeaderRow));

    chairRows.forEach((r,idx) => {
      const row = chairHeaderRow + 1 + idx;
      summary.getCell(row,1).value = r.name;
      summary.getCell(row,2).value = r.count;
      summary.getCell(row,3).value = r.gross;
      summary.getCell(row,4).value = r.barber;
      summary.getCell(row,5).value = r.shop;
    });
    styleDataRows(summary, chairHeaderRow+1, chairHeaderRow+chairRows.length, [3,4,5]);

    const barberStart = chairHeaderRow + chairRows.length + 3;
    summary.getCell(barberStart,1).value = "RESUMEN MENSUAL POR BARBERO";
    summary.getCell(barberStart,1).font = { size:13, bold:true, color:{argb:COLORS.text} };

    const barberHeader = barberStart + 1;
    ["Barbero","Servicios","Venta generada","Comisión %","Saldo barbero","Ingreso barbería"]
      .forEach((h,i)=>summary.getCell(barberHeader,i+1).value=h);
    styleHeader(summary.getRow(barberHeader));

    barberMonthly.forEach((r,idx) => {
      const row = barberHeader + 1 + idx;
      summary.getCell(row,1).value = r.name;
      summary.getCell(row,2).value = r.count;
      summary.getCell(row,3).value = r.gross;
      summary.getCell(row,4).value = r.commission / 100;
      summary.getCell(row,5).value = r.pay;
      summary.getCell(row,6).value = r.shop;
      summary.getCell(row,4).numFmt = pctFmt;
    });
    styleDataRows(summary, barberHeader+1, barberHeader+barberMonthly.length, [3,5,6]);

    summary.columns = [
      {width:24},{width:13},{width:18},{width:17},
      {width:18},{width:18},{width:16},{width:16}
    ];
    summary.views = [{state:"frozen", ySplit:4}];

    // =====================================================
    // HOJA 2: PUESTOS
    // =====================================================
    const chairsWs = wb.addWorksheet("Puestos", {
      properties:{ tabColor:{argb:"FF8A611D"} },
      pageSetup:{ orientation:"landscape", fitToPage:true, fitToWidth:1 }
    });
    setTitle(chairsWs, `Detalle por puesto · ${periodLabel}`, "Producción de cada puesto en el período seleccionado.", 5);
    const chHeaders = ["Puesto","Servicios","Total cobrado","Pago barberos","Ingreso barbería"];
    chHeaders.forEach((h,i)=>chairsWs.getCell(6,i+1).value=h);
    styleHeader(chairsWs.getRow(6));
    chairRows.forEach((r,idx)=>{
      const row=7+idx;
      chairsWs.getCell(row,1).value=r.name;
      chairsWs.getCell(row,2).value=r.count;
      chairsWs.getCell(row,3).value=r.gross;
      chairsWs.getCell(row,4).value=r.barber;
      chairsWs.getCell(row,5).value=r.shop;
    });
    styleDataRows(chairsWs,7,6+chairRows.length,[3,4,5]);
    chairsWs.columns=[{width:24},{width:14},{width:20},{width:20},{width:20}];
    chairsWs.views=[{state:"frozen",ySplit:6}];

    // =====================================================
    // HOJA 3: BARBEROS MENSUAL
    // =====================================================
    const bm = wb.addWorksheet("Barberos Mensual", {
      properties:{tabColor:{argb:COLORS.gold}}
    });
    setTitle(bm, `Barberos · Total mensual · ${periodLabel}`, "Venta generada, comisión y saldo del período.", 6);
    ["Barbero","Servicios","Venta generada","Comisión %","Saldo barbero","Ingreso barbería"]
      .forEach((h,i)=>bm.getCell(6,i+1).value=h);
    styleHeader(bm.getRow(6));
    barberMonthly.forEach((r,idx)=>{
      const row=7+idx;
      bm.getCell(row,1).value=r.name;
      bm.getCell(row,2).value=r.count;
      bm.getCell(row,3).value=r.gross;
      bm.getCell(row,4).value=r.commission/100;
      bm.getCell(row,5).value=r.pay;
      bm.getCell(row,6).value=r.shop;
      bm.getCell(row,4).numFmt=pctFmt;
    });
    styleDataRows(bm,7,6+barberMonthly.length,[3,5,6]);
    bm.columns=[{width:26},{width:14},{width:20},{width:16},{width:20},{width:20}];
    bm.views=[{state:"frozen",ySplit:6}];

    // =====================================================
    // HOJA 4: BARBEROS DIARIO
    // =====================================================
    const bd = wb.addWorksheet("Barberos Diario", {
      properties:{tabColor:{argb:"FFB88936"}}
    });
    setTitle(bd, `Saldo diario por barbero · ${periodLabel}`, "Detalle de cada día trabajado en el período.", 6);
    ["Fecha","Barbero","Servicios","Total cobrado","Saldo barbero","Ingreso barbería"]
      .forEach((h,i)=>bd.getCell(6,i+1).value=h);
    styleHeader(bd.getRow(6));
    dailyRows.forEach((r,idx)=>{
      const row=7+idx;
      const [y,m,d] = r.date.split("-").map(Number);
      bd.getCell(row,1).value = new Date(y,m-1,d);
      bd.getCell(row,1).numFmt = "dd-mmm-yyyy";
      bd.getCell(row,2).value = r.barberName;
      bd.getCell(row,3).value = r.count;
      bd.getCell(row,4).value = r.gross;
      bd.getCell(row,5).value = r.pay;
      bd.getCell(row,6).value = r.shop;
    });
    styleDataRows(bd,7,6+dailyRows.length,[4,5,6]);
    bd.columns=[{width:16},{width:26},{width:14},{width:20},{width:20},{width:20}];
    bd.views=[{state:"frozen",ySplit:6}];
    bd.autoFilter = { from:"A6", to:"F6" };

    // =====================================================
    // HOJA 5: COBROS
    // =====================================================
    const salesWs = wb.addWorksheet("Cobros", {
      properties:{tabColor:{argb:COLORS.dark}}
    });
    setTitle(salesWs, `Detalle completo de cobros · ${periodLabel}`, "Movimientos individuales registrados durante el período.", 9);
    ["Fecha","Barbero","Puesto","Servicio","Productos","Método","Total cobrado","Comisión servicio %","Comisión productos %","Ganancia servicio","Ganancia productos","Saldo barbero","Ingreso barbería"]
      .forEach((h,i)=>salesWs.getCell(6,i+1).value=h);
    styleHeader(salesWs.getRow(6));

    monthSales.forEach((s,idx)=>{
      const row=7+idx;
      salesWs.getCell(row,1).value=jsDate(s.date);
      salesWs.getCell(row,1).numFmt="dd-mmm-yyyy hh:mm";
      salesWs.getCell(row,2).value=s.barberName || "";
      salesWs.getCell(row,3).value=s.chairName || "";
      salesWs.getCell(row,4).value=s.serviceName || "";
      salesWs.getCell(row,5).value=Array.isArray(s.products) ? s.products.map(p => `${p.qty}x ${p.name}`).join(", ") : "";
      salesWs.getCell(row,6).value=s.payment || "";
      salesWs.getCell(row,7).value=Number(s.total||0);
      salesWs.getCell(row,8).value=Number(s.serviceCommission ?? s.commission ?? 0)/100;
      salesWs.getCell(row,8).numFmt=pctFmt;
      salesWs.getCell(row,9).value=Number(s.productCommission ?? 0)/100;
      salesWs.getCell(row,9).numFmt=pctFmt;
      salesWs.getCell(row,10).value=Number(s.serviceBarberAmount ?? s.barberAmount ?? 0);
      salesWs.getCell(row,11).value=Number(s.productBarberAmount ?? 0);
      salesWs.getCell(row,12).value=Number(s.barberAmount||0);
      salesWs.getCell(row,13).value=Number(s.shopAmount||0);
    });
    styleDataRows(salesWs,7,6+monthSales.length,[7,10,11,12,13]);
    salesWs.columns=[
      {width:21},{width:26},{width:18},{width:26},{width:34},
      {width:18},{width:18},{width:15},{width:18},{width:20}
    ];
    salesWs.views=[{state:"frozen",ySplit:6}];
    salesWs.autoFilter={from:"A6",to:"M6"};

    // Highlight total rows on summary
    const finalSummaryRow = barberHeader + barberMonthly.length + 2;
    summary.getCell(finalSummaryRow,1).value = "CIERRE DEL MES";
    summary.getCell(finalSummaryRow,1).font = {bold:true,color:{argb:COLORS.gold}};
    summary.getCell(finalSummaryRow,3).value = total;
    summary.getCell(finalSummaryRow,3).numFmt = currencyFmt;
    summary.getCell(finalSummaryRow,5).value = barberTotal;
    summary.getCell(finalSummaryRow,5).numFmt = currencyFmt;
    summary.getCell(finalSummaryRow,7).value = shopTotal;
    summary.getCell(finalSummaryRow,7).numFmt = currencyFmt;

    // Download
    const buffer = await wb.xlsx.writeBuffer();
    const blob = new Blob(
      [buffer],
      {type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Barberia_Los_Magicos_Reporte_${period.start}_${period.end}.xlsx`;
    a.click();
    URL.revokeObjectURL(url);

    toast("Excel premium generado correctamente.");
  } catch (err) {
    console.error(err);
    toast("No se pudo generar el Excel.");
  }
}

async function restoreSession(user) {
  if (!user || currentRole) return;

  if (user.isAnonymous) return;

  try {
    const snap = await getDoc(doc(db, "users", user.uid));
    if (!snap.exists()) {
      await signOut(auth);
      return;
    }

    const profile = { id:snap.id, ...snap.data() };

    if (profile.role === "admin" && profile.active !== false) {
      currentRole = "admin";
      currentAdmin = profile;
      hide("accessScreen");
      show("adminApp");
      $("adminDisplayName").textContent = profile.name || "Administrador";
      await ensureSeedData();
      subscribeAdmin();
    } else if (profile.role === "barber" && profile.active !== false) {
      currentRole = "barber";
      currentBarber = profile;
      hide("accessScreen");
      show("barberApp");
      subscribeBarber(profile.id);
    } else {
      await signOut(auth);
    }
  } catch (err) {
    console.error(err);
  }
}

async function main() {
  wireStaticUI();
  const todayLabel = $("todayLabel");
  if (todayLabel) {
    todayLabel.textContent = new Date().toLocaleDateString("es-PA", { weekday:"long", day:"2-digit", month:"long" });
  }

  const ready = await initFirebase();
  if (!ready) return;

  onAuthStateChanged(auth, restoreSession);
}

main().catch(err => {
  console.error("[Los Mágicos] Error de inicialización:", err);
  const alert = $("firebaseAlert");
  if (alert) {
    alert.textContent = "La aplicación no pudo completar la inicialización. Recarga la página con Ctrl + F5.";
    alert.classList.remove("hidden");
  }
});
